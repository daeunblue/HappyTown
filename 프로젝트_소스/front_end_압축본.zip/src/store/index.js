import Vue from 'vue';
import Vuex from 'vuex';
import createPersistedState from 'vuex-persistedstate';

Vue.use(Vuex);

import axios from "axios";

export default new Vuex.Store({
  state: {
    //baseURL: 'http://localhost:8000',
    baseURL: 'http://ssafy.ddns.net:8000',
    serviceName: 'Happy Town',
    wait: false,
    token: {
      accessToken: null,
    },
    notification: {
      items: [],
    },
    user: {
      isAuthenticated: false,
      id: '',
      name: '',
      address: '',
      interestCnt: 0,
    },
    selected: {
      cityName: '',
      cityCode: '',
      gugunCode: '',
      gugunName: '',
    },
  },
	getters: {
		getNotiCnt(state) {
			return state.notification.items.length;
		},
    getBaseURL: function (state) {
      return state.baseURL;
    },
    getAccessToken: function (state) {
      return state.token.accessToken;
    },
    isAuthenticated: function (state) {
      return state.user.isAuthenticated;
    },
    getUserId(state) {
      return state.user.id;
    },
    getUserName(state) {
      return state.user.name;
    },
    getCityName(state) {
      return state.selected.cityName;
    },
    getCityCode(state) {
      return state.selected.cityCode;
    },
    getGugunCode(state) {
      return state.selected.gugunCode;
    },
    getGugunName(state) {
      return state.selected.gugunName;
    },
    getUserCnt(state) {
      return state.user.interestCnt;
    },
    getWait(state) {
      return state.wait;
    }
  },
  mutations: {
    logout: function (state) {
      state.token.accessToken = '';
      state.user.isAuthenticated = false;
      state.user.name = '';
      state.user.id = '';
      state.user.interestCnt = 0;
      state.notification.items = [];
    },
    setAccessToken: function (state, payload = {}) {
      console.log('payload', payload);
      state.user.id = payload.id;
      state.user.name = payload.name;
      state.user.address = payload.address;
      state.user.isAuthenticated = true;
      if (payload.accessToken) {
        state.token.accessToken = payload.accessToken;
      }
    },
    setWait: function(state, payload = {}) {
      state.wait = payload.wait;
    },
    setGugunCode: function (state, payload = {}) {
      state.selected.gugunCode = payload;
    },
    setGugunName: function (state, payload = {}) {
      state.selected.gugunName = payload;
    },
    setUserCnt: function (state, payload = {}) {
      state.user.interestCnt = payload;
    },
    addUserCnt: function (state, payload = 1) {
      return (state.user.interestCnt = state.user.interestCnt + payload);
		},
		setNotiItems: function (state, payload = {}) {
			state.notification.items = payload.items;
		}
  },
  actions: {
		getNoti({ commit, getters }) {
			if (getters.isAuthenticated) {				
				axios.get(getters.getBaseURL + "/api/notification/" + getters.getUserId, {
					headers: {
						"jwt-auth-token": getters.getAccessToken,
					},
				})
					.then((res) => {
						commit("setNotiItems", { items: res.data });
					})
					.catch((error) => {
						alert("알림 불러오기 네트워크 오류 or 토큰 만료")
						console.log(error);
					})
			}
		},
	},
  modules: {},
  plugins: [
    createPersistedState({
      storage: window.sessionStorage,
    }),
  ],
});
