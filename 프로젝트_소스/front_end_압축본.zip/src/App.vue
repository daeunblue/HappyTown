<template>
  <div>
    <section class="section-shaped my-0 pt-0 min">
      <div class="shape shape-style-1 shape-default shape-skew">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="container">
        <app-header></app-header>
        <base-alert v-if="$store.getters.getNotiCnt" type="success" dismissible>
          <span class="alert-inner--icon"><i class="ni ni-bell-55"></i></span>
          <span class="alert-inner--text"
            ><strong>{{ $store.getters.getUserName }}님!</strong> 도착한 알림을 확인해보세요!</span
          >
        </base-alert>

        <fade-transition origin="center" mode="out-in" :duration="250">
          <main>
            <router-view></router-view>
          </main>
        </fade-transition>
        <!-- <app-footer></app-footer> -->
      </div>
    </section>
  </div>
</template>

<script>
import { FadeTransition } from "vue2-transitions";
import AppHeader from "@/layout/AppHeader.vue";
import AppFooter from "@/layout/AppFooter.vue";

export default {
  name: "HappyhouseVueFrontApp",
  components: { AppHeader, AppFooter, FadeTransition },

  data() {
    return {};
  },

  mounted() {},

  methods: {},
};
</script>

<style scoped>
.min {
  min-height: 98vh;
}
</style>
