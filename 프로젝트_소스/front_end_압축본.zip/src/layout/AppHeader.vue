<template>
  <header class="header-global">
    <base-nav class="navbar-main" transparent type="" effect="light" expand>
      <!-- 좌상단 로고 -->
      <router-link slot="brand" class="navbar-brand mr-lg-5" to="/">
        <!-- <img src="@/assets/img/brand/white.png" alt="logo" /> -->
        <i class="ni ni-building mr-2 text-white"></i>
        <span class="text-white font-weight">{{ this.$store.state.serviceName }}</span>
      </router-link>

      <!-- 닫기 버튼 -->
      <div class="row" slot="content-header" slot-scope="{ closeMenu }">
        <div class="col-6 collapse-brand">
          <a href="https://demos.creative-tim.com/vue-argon-design-system/documentation/">
            <img src="" />
          </a>
        </div>
        <div class="col-6 collapse-close">
          <close-button @click="closeMenu"></close-button>
        </div>
      </div>

      <ul class="navbar-nav navbar-nav-hover align-items-lg-center">
        <!-- dropdown 버튼 1 -->
        <base-dropdown class="nav-item" menu-classes="dropdown-menu-xl">
          <a slot="title" href="#" class="nav-link" data-toggle="dropdown" role="button">
            <i class="ni ni-ui-04 d-lg-none"></i>
            <span class="nav-link-inner--text text-light">메인 서비스</span>
          </a>

          <div class="dropdown-menu-inner p-0" style="min-width: 250px">
            <router-link to="/towninfo" class="media d-flex align-items-center dropdown-item">
              <div class="align-self-center">
                <icon name="ni ni-square-pin" type="primary" rounded class="mb-2 mt-2"> </icon>
              </div>
              <div class="media-body ml-3">
                <h6 class="heading text-primary">동네 한눈에 보기</h6>
                <p class="description d-none d-md-inline-block mb-0">
                  범죄율, 실거래가 추이, 주변 상권정보까지 한눈에!
                </p>
              </div>
            </router-link>
            <router-link to="/house" class="media d-flex align-items-center dropdown-item">
              <div class="">
                <icon name="ni ni-building" type="success" rounded class="mb-2 mt-2"> </icon>
              </div>
              <div class="media-body ml-3">
                <h5 class="heading text-success">APT 찾아보기</h5>

                <p class="description d-none d-md-inline-block mb-0">
                  위치 · 가격 · 평수 원하는 아파트 찾기
                </p>
              </div>
            </router-link>
          </div>
        </base-dropdown>
        <!-- dropdown 버튼 2 -->
        <base-dropdown class="nav-item" menu-classes="dropdown-menu-xl">
          <a slot="title" href="#" class="nav-link" data-toggle="dropdown" role="button">
            <i class="ni ni-ui-04 d-lg-none"></i>
            <span class="nav-link-inner--text text-light">맞춤 서비스</span>
          </a>

          <div class="dropdown-menu-inner p-0" style="min-width: 250px">
            <router-link to="/board" class="media d-flex align-items-center dropdown-item">
              <div class="align-self-center">
                <icon
                  name="ni ni-chat-round"
                  rounded
                  class="mb-2 mt-2"
                  style="background-color: gold; color: orange"
                >
                </icon>
              </div>
              <div class="media-body ml-3">
                <h6 class="heading text-warning">Q&A 게시판</h6>
                <p class="description d-none d-md-inline-block mb-0">궁금한 정보를 함께 나눠요!</p>
              </div>
            </router-link>
            <router-link to="/interest" class="media d-flex align-items-center dropdown-item">
              <div class="">
                <icon
                  name="ni ni-favourite-28"
                  rounded
                  class="mb-2 mt-2"
                  style="background-color: pink; color: fuchsia"
                >
                </icon>
              </div>
              <div class="media-body ml-3">
                <h5 class="heading text-success">관심 APT 동네 모아보기</h5>
                <p class="description d-none d-md-inline-block mb-0">
                  내가 원하는 아파트의 동네 어떤 곳일까?
                </p>
              </div>
            </router-link>
            <router-link to="/salelist" class="media d-flex align-items-center dropdown-item">
              <div class="">
                <icon name="ni ni-folder-17" rounded class="mb-2 mt-2" type="info"> </icon>
              </div>
              <div class="media-body ml-3">
                <h5 class="heading text-info">회원 APT 매물 목록</h5>
                <p class="description d-none d-md-inline-block mb-0">
                  {{ this.$store.state.serviceName }} 회원간 APT를 거래해보세요
                </p>
              </div>
            </router-link>
          </div>
        </base-dropdown>
      </ul>
      <ul class="navbar-nav align-items-lg-center ml-lg-auto">
        <!-- nav 우측 정렬 위젯 -->
        <li v-if="isAuthenticated" class="text-white mr-3">{{ name }}님 안녕하세요</li>
        <!-- 알림 없을때 뜰 아이콘 -->
        <li v-if="!$store.state.notification.items.length && $store.getters.isAuthenticated" class="">
          <div class="justify-content-center">
            <icon name="ni ni-bell-55" rounded class="mb-2 mt-2 noti-off"> </icon>
          </div>
        </li>
        <!-- 알림 있을때 뜰 아이콘 -->
        <li v-if="$store.state.notification.items.length && $store.getters.isAuthenticated" class="">
          <base-dropdown menu-classes="dropdown-menu-xl">
            <a slot="title" href="#" class="" data-toggle="dropdown" role="button">
              <div>
                <div class="justify-content-center">
                  <icon name="ni ni-bell-55" rounded class="mb-2 mt-2 noti-on"> </icon>
                </div>
              </div>
            </a>
            <!-- v-if로 알림 목록  -->
            <div v-for="(item, index) in $store.state.notification.items" :key="index" class="dropdown-menu-inner p-0" style="min-width: 250px">
              <a @click="noti(item)" href="#" id="my-a" class="media d-flex align-items-center dropdown-item">
                <div class="media-body ml-3">
                  <h6 class="heading text-primary">{{item.dongName | myfilter}}</h6>
                  <p class="description d-none d-md-inline-block mb-0">
                    {{item.title}}
                  </p>
                </div>
              </a>
            </div>
          </base-dropdown>
        </li>
        <li v-if="isAuthenticated" class="nav-item my d-lg-block ml-lg-4">
          <router-link to="/userinfo" class="btn btn-neutral btn-icon bg-white">
            <span class="btn-inner--icon">
              <i class="ni ni-circle-08 mr-2"></i>
            </span>
            <span class="nav-link-inner--text">내정보</span>
          </router-link>
        </li>
        <li v-if="isAuthenticated" class="nav-item my d-lg-block ml-1">
          <button @click="tryLogout" class="btn btn-neutral btn-icon bg-white">
            <span class="btn-inner--icon">
              <i class="ni ni-bold-right mr-2"></i>
            </span>
            <span class="nav-link-inner--text">로그아웃</span>
          </button>
        </li>
        <li v-if="!isAuthenticated" class="nav-item my d-lg-block ml-lg-4">
          <router-link to="/login" class="btn btn-neutral btn-icon bg-white">
            <span class="btn-inner--icon">
              <i class="ni ni-active-40 mr-2"></i>
            </span>
            <span class="nav-link-inner--text">로그인</span>
          </router-link>
        </li>
        <li v-if="!isAuthenticated" class="nav-item my d-lg-block ml-1">
          <router-link to="/register" class="btn btn-neutral btn-icon bg-white">
            <span class="btn-inner--icon">
              <i class="ni ni-fat-add mr-2" style="font-size: 17px"></i>
            </span>
            <span class="nav-link-inner--text">회원가입</span>
          </router-link>
        </li>
      </ul>
    </base-nav>
  </header>
</template>
<script>
import ai from "@/js/axios.js";
import BaseNav from "@/components/BaseNav";
import BaseDropdown from "@/components/BaseDropdown";
import CloseButton from "@/components/CloseButton";
import { mapGetters } from "vuex";

export default {
  data(){
    return {

    }
  },
  components: {
    BaseNav,
    CloseButton,
    BaseDropdown,
  },
  computed: {
    ...mapGetters(["isAuthenticated"]),
    name() {
      return this.$store.state.user.name;
    },
  },
  methods: {
    noti(item){
      // 게시물일 경우에만.
      if(item.aptSaleNo > 0){
        if(this.$route.path != '/salelist'){
          this.$router.push("/salelist");
        }
      }
      // 알림 삭제
      ai.delete('/notification/'+item.no,{
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      }).then(()=>{
        this.$store.dispatch('getNoti');
      });
    },
    tryLogout() {
      this.$store.commit("logout");
      if (this.$route.path != "/") {
        this.$router.push("/");
      }
    },
  },
  filters: {
    myfilter(text){
      if(text.charAt(2) == '동'){
        return text+" 매물";
      }
      else{ 
        return text;
      }
    }
  }
};
</script>
<style scoped>
.noti-off {
  background-color: rgba(255, 255, 255, 0.62);
}

.noti-on {
  background-color: rgba(255, 255, 255, 0.8);
  color: #39ca8b;
}
.noti-on:hover {
  background-color: rgba(255, 255, 255, 0.637);
  color: #83f0c0;
}

.my {
  z-index: 5;
}

.navbar-nav .nav-item .media:not(:last-child) {
  margin-bottom: 0px;
}
</style>
