import axios from "axios";

const getSidoList = async function (dropdown) {
  try {
    const res = await axios.get("https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes?regcode_pattern=*00000000");
    dropdown.sidoList = res.data.regcodes;
  } catch (error) {
    alert("regcodes error");
    console.log(error);
  }
}

const getGugunList = async function (dropdown) {
  dropdown.gugunList = [];
  dropdown.gugunCaret = true;
  dropdown.gugunName = "구/군";
  dropdown.gugunCode = "";
  dropdown.dongList = [];
  dropdown.dongCaret = true;
  dropdown.dongName = "동";
  dropdown.dongCode = "";
  try {
    let temp = dropdown.sidoCode.substr(0, 2)
    const res = await axios.get("https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes?regcode_pattern="+temp+"***0000");
    for (let item of res.data.regcodes) {
      let gugunName = item.name.split(" ")[1];
      if (gugunName) {
        item.name = gugunName;
        dropdown.gugunList.push(item);
      }
    }
  } catch (error) {
    alert("regcodes error");
    console.log(error);
  }
}

const getDongList = async function (dropdown) {
  dropdown.dongList = [];
  dropdown.dongCaret = true;
  dropdown.dongName = "동";
  dropdown.dongCode = "";
  try {
    let temp = dropdown.gugunCode.substr(0,4);  
    const res = await axios.get("https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes?regcode_pattern="+temp+"*");
    for (let item of res.data.regcodes) {
      let dongName = item.name.split(" ")[2];
      if (dongName) {
        item.name = dongName;
        dropdown.dongList.push(item);
      }
    }
  } catch (error) {
    alert("regcodes error");
    console.log(error);
  }
}

export { getSidoList, getGugunList, getDongList };