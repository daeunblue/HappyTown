import Vue from 'vue';
import VueRouter from 'vue-router';
// import Components from "@/views/Components.vue";
import HomeView from '@/views/HomeView.vue';
import Board from '@/views/board/Board.vue';
import BoardWrite from '@/views/board/BoardWrite.vue';
import BoardDetail from '@/views/board/BoardDetail.vue';
import BoardModify from '@/views/board/BoardModify.vue';
import SaleList from '@/views/aptsale/SaleList.vue';
import SaleWrite from '@/views/aptsale/SaleWrite.vue';
import SaleDetail from '@/views/aptsale/SaleDetail.vue';
import House from '@/views/house/House.vue';
import Login from '@/views/Login.vue';
import UserInfo from '@/views/UserInfo.vue';
import Register from '@/views/Register.vue';
import TownInfo from '@/views/TownInfo.vue';
import Chart from '@/views/components/Charts/CrimeChart.vue';
import UserInterest from '@/views/house/Interest.vue';
import store from "@/store";
Vue.use(VueRouter);

const requireAuth = () => (to, from, next) => {
  if (store.getters.getAccessToken) {
    return next();
  }
  next('/login');
}


const routes = [
  {
    path: '/',
    name: 'components',
    component: HomeView,
  },
  {
    path: '/board',
    name: 'board',
    component: Board,
    beforeEnter: requireAuth()
  },
  {
    path: '/boardwrite',
    name: 'boardwrite',
    component: BoardWrite,
    beforeEnter: requireAuth()
  },
  {
    path: '/boarddetail',
    name: 'boarddetail',
    component: BoardDetail,
    beforeEnter: requireAuth()
  },
  {
    path: '/boardmodify',
    name: 'boardmodify',
    component: BoardModify,
    beforeEnter: requireAuth()
  },
  {
    path: '/salelist',
    name: 'salelist',
    component: SaleList,
    beforeEnter: requireAuth()
  },
  {
    path: '/salewrite',
    name: 'salewrite',
    component: SaleWrite,
    beforeEnter: requireAuth()
  },
  {
    path: '/saledetail',
    name: 'saledetail',
    component: SaleDetail,
    beforeEnter: requireAuth()
  },

  {
    path: '/house',
    name: 'house',
    component: House,
    beforeEnter: requireAuth()
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
  },
  {
    path: '/userinfo',
    name: 'userinfo',
    component: UserInfo,
    beforeEnter: requireAuth()
  },
  {
    path: '/register',
    name: 'register',
    component: Register,
  },
  {
    path: '/towninfo',
    name: 'towninfo',
    component: TownInfo,
    beforeEnter: requireAuth()
  },
  {
    path: '/chart',
    name: 'Chart',
    component: Chart,
    beforeEnter: requireAuth()
  },
  {
    path: '/interest',
    name: 'Interest',
    component: UserInterest,
    beforeEnter: requireAuth()
  },
];

const router = new VueRouter({
  routes,
});

export default router;
