<template>
  <section class="section section-shaped section-lg my-0">
    <div class="container pt-lg-md">
      <div class="row justify-content-center">
        <div class="col-lg-5" style="min-width: 432px;">
          <card
            type="white"
            shadow
            header-classes="bg-white pb-5"
            body-classes="px-lg-5 py-lg-5"
            class="border-0"
          >
            <template>
              <div class="text-muted text-center mb-3">
                <small>Sign in with</small>
              </div>
              <div class="btn-wrapper text-center">
                <div class="" style="min-width: 300px;">
                  <img @click="kakaologin" class="my-hover rounded shadow mb-3" src="@/assets/img/kakao_login_medium_wide.png" alt="">
                </div>
              </div>
            </template>
            <template>
              <div class="text-center text-muted mb-4">
                <small>Or sign in with credentials</small>
              </div>
              <form role="form">
                <base-input
                  alternative
                  type="text"
                  class="mb-3"
                  placeholder="ID"
                  addon-left-icon="ni ni-email-83"
                  v-model="id"
                >
                </base-input>
                <base-input
                  alternative
                  type="password"
                  placeholder="Password"
                  v-model="password"
                  addon-left-icon="ni ni-lock-circle-open"
                >
                </base-input>
                <base-checkbox> Remember me </base-checkbox>
                <div class="text-center">
                  <base-button type="primary" class="my-4" @click="tryLogin">로그인</base-button>
                </div>
              </form>
            </template>
          </card>
          <div class="row mt-3">
            <div class="col-6">
              <a href="#" class="text-light">
                <small>Forgot password?</small>
              </a>
            </div>
            <div class="col-6 text-right">
              <a href="#" class="text-light">
                <small>Create new account</small>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from "axios";

export default {
	name: "HappyhouseFinalSeoul11FrontKimdaeunKimdaeheeLogin",

	data() {
		return {
			id: null,
			password: null,
		};
	},

	mounted() {},

	methods: {
    kakaologin(){
      //window.location.href="https://kauth.kakao.com/oauth/authorize?client_id=af19bb5087982aa80afec24c84c155ef&redirect_uri=http://localhost:8080/&response_type=code"
      window.location.href="https://kauth.kakao.com/oauth/authorize?client_id=af19bb5087982aa80afec24c84c155ef&redirect_uri=http://ssafy.ddns.net/&response_type=code"
    },
		tryLogin() {
			axios
				.post(this.$store.getters.getBaseURL+"/user/login", {
					id: this.id,
					password: this.password,
				})
				.then((res) => {
					if (res.data.success) {
						this.$store.commit("setAccessToken", {
							accessToken: res.data["jwt-auth-token"],
							id: res.data.data.id,
							name: res.data.data.name,
							address: res.data.data.address
						});

						this.$router.push("/");
					} else {
						alert("로그인 실패");
					}
				})
				.catch((error) => {
					alert("네트워크 에러");
					console.log(error);
				});
		},
	},
};
</script>

<style scoped>
.my-hover:hover {
  cursor: pointer;
}
</style>
