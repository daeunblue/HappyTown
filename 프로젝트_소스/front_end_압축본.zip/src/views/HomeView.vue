<template>
  <div>
    <div>

      <div class="row">
        <div class="col-lg-8">
          <h1 class="display-3 text-white" style="line-height: 96px">
            당신에게 <br />
            딱! 맞는<br />
            동네를 추천해주는 <br />
            HAPPY TOWN
            <!-- PROFIT VILLAGE -->
          </h1>
          <p class="lead text-white">
            아직도 어느 동네 매물을 봐야할지 고민이신가요? <br />
            가격, 위치, 상권 이 모든 정보를<br />
            한눈에 확인 해보고 결정하세요!
          </p>
        </div>
      </div>
    </div>
    <section class="section section-lg pt-lg-0">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-12">
            <div class="row row-grid">
              <div class="col-lg-4 my-hover" @click="town">
                <card class="my-card border-0" hover shadow body-classes="py-5">
                  <icon name="ni ni-square-pin" type="primary" rounded class="mb-4"> </icon>
                  <h6 class="text-primary h4">동네 한눈에 보기</h6>
                  <div class="my-class description mt-3">
                    동네별 범죄율 · 실거래가 추이 · 주변 상권정보까지 한눈에! 살기 좋은 동네를 같이
                    찾아봐요!
                  </div>
                  <div>
                    <badge type="primary" rounded>design</badge>
                    <badge type="primary" rounded>system</badge>
                    <badge type="primary" rounded>creative</badge>
                  </div>
                  <base-button tag="a" href="#" type="primary" class="mt-4">
                    한눈에 보기
                  </base-button>
                </card>
              </div>

              <div class="col-lg-4 my-hover" @click="apt">
                <card class="my-card border-0" hover shadow body-classes="py-5">
                  <icon name="ni ni-building" type="success" rounded class="mb-4"> </icon>
                  <h6 class="text-success h4">APT 찾아보기</h6>
                  <div class="my-class description mt-3">
                    내가 원하는 위치 · 가격 · 평수의 <br />
                    아파트를 편리하게
                  </div>
                  <div>
                    <badge type="success" rounded>business</badge>
                    <badge type="success" rounded>vision</badge>
                    <badge type="success" rounded>success</badge>
                  </div>
                  <base-button tag="a" href="#" type="success" class="mt-4"> 찾아보기 </base-button>
                </card>
              </div>

              <div class="col-lg-4 my-hover" @click="qna">
                <card class="my-card border-0" hover shadow body-classes="py-5">
                  <icon name="ni ni-folder-17" rounded class="mb-4" type="info"> </icon>
                  <h6 class="text-info h4">회원 APT 매물 목록</h6>
                  <div class="my-class description mt-3">
                    {{ this.$store.state.serviceName }} 회원간 APT 매물을 직접 거래하거나 매물을
                    올려보세요!
                  </div>
                  <div>
                    <badge type="info" rounded>marketing</badge>
                    <badge type="info" rounded>product</badge>
                    <badge type="info" rounded>launch</badge>
                  </div>
                  <base-button tag="a" href="#" type="info" class="mt-4"> TALK </base-button>
                </card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "HappyhouseVueFrontHomeView",

  data() {
    return {
      code: "",
    };
  },

  created() {
    this.create();
  },

  mounted() {
    this.$store.dispatch("getNoti");
  },

  methods: {
    create() {
      const URLSearch = new URLSearchParams(location.search);
      this.code = URLSearch.get("code");
      if (!this.$store.getters.isAuthenticated && this.code) {
        console.log(
          "로그인 요청 url :" + this.$store.getters.getBaseURL + "/oauth/kakao?code=" + this.code
        );
        axios
          .get(this.$store.getters.getBaseURL + "/oauth/kakao?code=" + this.code)
          .then((res) => {
            console.log(res);
            this.$store.commit("setAccessToken", {
              id: res.data.id,
              name: "[kakao]" + res.data.name,
              address: "",
              accessToken: res.data.token,
            });
            window.location.href = "/";
          })
          .catch((error) => {
            alert("네트워크 에러");
            console.log(error);
          });
      }
    },

    town() {
      if (this.$store.getters.getAccessToken) {
        this.$router.push("/towninfo");
      } else {
        this.$router.push("/login");
      }
    },
    apt() {
      if (this.$store.getters.getAccessToken) {
        this.$router.push("/house");
      } else {
        this.$router.push("/login");
      }
    },
    qna() {
      if (this.$store.getters.getAccessToken) {
        this.$router.push("/salelist");
      } else {
        this.$router.push("/login");
      }
    },
  },
};
</script>

<style scoped>
/* .alert-dismissible .close {
  position: relative !important;
} */

.my-hover:hover {
  cursor: pointer;
}

.my-class {
  height: 90px;
  line-height: 32px;
}
</style>
