<template>
  <div>
    <div>
      <div class="row">
        <div class="col-lg-6">
          <h1 class="display-3 text-white">
            한눈에 <br />볼 수 있는 <br />
            우리 동네 정보
          </h1>
          <p class="lead text-white">
            범죄율, 실거래가, 주변 상권 정보까지 한눈에!
          </p>
        </div>
      </div>
    </div>
    <div>
      <!-- 드롭다운 -->
      <div class="row d-flex justify-content-center mb-3">
        <b-dropdown
          id="dropdown-1"
          block
          :text="selectedCity.name"
          class="col-2"
        >
          <b-dropdown-item
            v-for="city in citys"
            :key="city.name"
            :value="city.name"
            @click="
              [
                (selectedCity.name = city.name),
                (selectedCity.code = city.code),
                guSelected(),
              ]
            "
            >{{ city.name }}
          </b-dropdown-item>
        </b-dropdown>
        <b-dropdown
          id="dropdown-1"
          block
          :text="selectedGu.name"
          class="col-2"
          :val="selectedGu.name"
        >
          <b-dropdown-item
            v-for="gu in gus"
            :key="gu.name"
            :value="gu"
            @click="
              [
                (selectedGu.name = gu.name),
                (selectedGu.code = gu.code),
                gugunSelected(),
              ]
            "
            >{{ gu.name }}</b-dropdown-item
          >
        </b-dropdown>
      </div>
      <div>
        <div>
          <tabs class="flex-column flex-md-row" tab-content-classes="border-0">
            <card not no-body bodyClasses="bg-default">
              <tab-pane>
                <span slot="title">
                  <i class="ni ni-world"></i>
                  치안/가격
                </span>
                <div>
                  <div class="" id="">
                    <database-chart
                      card-title="범죄 지수"
                      card-text="<p>늦은 시간에도 안심하고 <br>돌아다닐 수 있는 안전한 동네를 <br>찾는 여러분께 해당 동네의 <br>5대 범죄 발생률을 알려드릴게요"
                      label-title="인구수 10,000명당 범죄 발생 수 (건)"
                      chart-type="bar"
                      :request-url="
                        this.$store.getters.getBaseURL + '/api/chart/gugunInfo/'
                      "
                      element-name="gugunName"
                      element-value="crimeCntPerPopulation10000"
                      icon="single-02"
                      icon-type="danger"
                    >
                    </database-chart>
                    <database-chart
                      card-title="부동산 실 거래가"
                      card-text="<p>동네별 실제 거래 가격<br> 찾느라 많이 힘드셨죠?<br>동별 아파트 실거래가를<br> 차트로 한 번에 알려드릴게요!"
                      label-title="최근 4개년 평균 평당 거래가 (만 원)"
                      chart-type="line"
                      :request-url="
                        this.$store.getters.getBaseURL + '/api/chart/deal/'
                      "
                      element-name="dongName"
                      element-value="avgDealAmountPerArea"
                      icon="building"
                      icon-type="success"
                    >
                    </database-chart>
                  </div>
                </div>
              </tab-pane>

              <tab-pane title="Profile">
                <span slot="title">
                  <i class="ni ni-square-pin mr-2"></i>
                  상권/교육
                </span>
                <div>
                  <div class="" id="my2">
                    <database-chart
                      card-title="음식점 상권"
                      card-text="<p>식食은 인간이 기본적으로<br>갖춰야할 의식주 중 하나로,<br> 삶의 큰 즐거움이에요. <br>동네의 음식점 상권이 얼마나<br> 잘 형성되어있는지 보여드릴게요! "
                      label-title="음식점 개수"
                      chart-type="bar"
                      :cborderRadius="Number.MAX_VALUE"
                      :request-url="
                        this.$store.getters.getBaseURL +
                        '/api/chart/store/음식/'
                      "
                      element-name="dongName"
                      element-value="kindCnt"
                      icon="shop"
                      icon-type="warning"
                    >
                    </database-chart>
                    <database-chart
                      card-title="학원/교육 지수"
                      card-text="<p> <b>맹모삼천지교(孟母三遷之敎)</b><br>라는 말이 있듯이<br> 우리 아이의 10대를 책임질<br> 동네의 교육지수도<br> 한눈에 보여드릴게요!"
                      label-title="학원, 교육시설 개수"
                      chart-type="line"
                      :request-url="
                        this.$store.getters.getBaseURL +
                        '/api/chart/store/학문/'
                      "
                      element-name="dongName"
                      element-value="kindCnt"
                      icon="hat-3"
                      icon-type="info"
                    >
                    </database-chart>
                  </div>
                </div>
              </tab-pane>

              <tab-pane>
                <span slot="title">
                  <i class="ni ni-user-run"></i>
                  체육/환경
                </span>
                <div>
                  <div class="" id="my3">
                    <database-chart
                      card-title="체육 시설 지수"
                      card-text="평소에 운동할 곳이<br>마땅치 않아 고민이셨나요?<br>질병 예방과 정신적 안정감을<br> 주는 '운동'을 할 만한 곳이<br> 얼마나 있는지 보여드릴게요!"
                      label-title="체육 시설 개수"
                      chart-type="bar"
                      :cborderRadius="Number.MAX_VALUE"
                      :request-url="
                        this.$store.getters.getBaseURL +
                        '/api/chart/store/스포츠/'
                      "
                      element-name="dongName"
                      element-value="kindCnt"
                      icon="user-run"
                      icon-type="default"
                    >
                    </database-chart>
                    <div class="row px-3">
                      <database-chart
                        class="col-6"
                        card-title="대기오염 배출업체"
                        card-text="<p class='air'>장기적 노출시<br> 폐 질환 등을<br>유발하는 <br>미세먼지! <br>해당 동네의 <br>대기오염 지수 보여드릴게요!"
                        label-title="대기오염 배출 업체 수"
                        chart-type="doughnut"
                        :request-url="
                          this.$store.getters.getBaseURL +
                          '/api/chart/gugunInfo/'
                        "
                        element-name="gugunName"
                        element-value="polluterCnt"
                        icon=""
                        icon-type=""
                        chartWidth="370"
                        :chartHeight="450"
                      >
                      </database-chart>
                      <database-chart
                        class="col-6"
                        card-title="공원 수"
                        card-text="<p class='air'>주말과 같은 <br>여가시간을<br> 상쾌하게 <br>보낼 수 있는<br> 공원이 동네에<br> 얼마나 있는지<br> 보여드릴게요!"
                        label-title="공원 개수"
                        chart-type="bar"
                        :request-url="
                          this.$store.getters.getBaseURL +
                          '/api/chart/gugunInfo/'
                        "
                        element-name="gugunName"
                        element-value="parkCnt"
                        icon=""
                        icon-type=""
                        chartWidth="370"
                        :chartHeight="450"
                      >
                      </database-chart>
                    </div>
                  </div>
                </div>
              </tab-pane>
            </card>
          </tabs>
        </div>
      </div>
      <div class=""></div>
    </div>
  </div>
</template>

<script>
import CrimeChart from './components/Charts/CrimeChart.vue';
import DatabaseChart from './components/Charts/DatabaseChart.vue';
import Tabs from '@/components/Tabs/Tabs.vue';
import TabPane from '@/components/Tabs/TabPane.vue';
import axios from 'axios';

export default {
  name: 'HappyhouseFinalSeoul11FrontKimdaeunKimdaeheeTownInfo',
  components: { CrimeChart, DatabaseChart, Tabs, TabPane },
  component: {
    CrimeChart,
    DatabaseChart,
    Tabs,
    TabPane,
  },
  data() {
    return {
      citys: {},
      selectedCity: {
        code: '',
        name: '',
      },
      selectedGu: {
        code: '',
        name: '',
      },
      gus: [],
      val: '',
      gugunCode: '',
    };
  },
  created() {
    let query = this.$route.query;
    if (query.dongCode) {
      this.selectedCity.name = '서울광역시';
      this.selectedCity.code = '1100000000';
      this.selectedGu.name = '';
      this.selectedGu.code = query.dongCode.substring(0, 4) + '000000';
    } else {
      this.selectedCity.name = '서울광역시';
      this.selectedCity.code = '1100000000';
      this.selectedGu.name = '강남구';
      this.selectedGu.code = '1168000000';
      this.$store.state.selected.gugunCode = this.selectedGu.code;
    }

    this.$store.commit('setGugunCode', this.selectedGu.code);
    this.$store.commit('setGugunName', this.selectedGu.name);
    // 초기값
    this.guSelected();

    axios
      .get(
        'https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes?regcode_pattern=*00000000',
      )
      .then((res) => {
        if (res.status == 200) {
          //this.citys = res.data.regcodes;
          this.citys = [{
            code: "1100000000",
            name: "서울특별시"
          }]
        }
      })
      .catch((err) => {
        console.log(err);
      });
  },
  methods: {
    guSelected() {
      this.gus = {};
      var temp = this.selectedCity.code.substring(0, 2);
      // console.log(this.selectedCity.name + ", " + this.selectedCity.code);

      axios
        .get(
          'https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes?regcode_pattern=' +
            temp +
            '*000000',
        )
        .then((res) => {
          if (res.status == 200) {
            var guArr = [];
            for (let regcode of res.data.regcodes) {
              let city_name = regcode.name;
              if (city_name.split(' ')[1]) {
                guArr.push({
                  code: regcode.code,
                  name: city_name.split(' ')[1],
                });
              }
            }
            this.gus = guArr;
            // console.log(this.gus);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    gugunSelected() {
      // 추가 구현해야할 기능 -> 해당 동 코드를 자식 component들에게 전달하고, 자식 component들은 알아서 차트 변경시키기
      // Vuex 활용해서 처리하자 !
      this.$store.commit('setGugunCode', this.selectedGu.code);
      this.$store.commit('setGugunName', this.selectedGu.name);
    },
  },
  watch: {
    '$store.state.selected.gugunName': function () {
      if (this.$store.state.selected.gugunName) {
        this.selectedGu.name = this.$store.state.selected.gugunName;
      }
    },
  },
};
</script>

<style>
.chart-box {
  margin-bottom: 1em;
}
p {
  padding: 5px;
}
.air {
  margin: 0%;
  padding: 0%;
}
</style>

<style scoped>
::v-deep .dropdown-menu {
  max-height: 330px;
  overflow-y: auto;
}
</style>
