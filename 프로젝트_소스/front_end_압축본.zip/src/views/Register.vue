<template>
  <section class="section section-shaped section-lg my-0">
    <div class="container pt-lg-md" id="">
      <div class="row justify-content-center">
        <div class="col-lg-5" style="min-width: 432px;">
          <card
            type="white"
            shadow
            header-classes="bg-white pb-5"
            body-classes="px-lg-5 py-lg-5"
            class="border-0"
          >
            <template>
              <div class="text-muted text-center mb-3">
                <small>Sign in with</small>
              </div>
              <div class="btn-wrapper text-center">
                <div class="">
                  <img
                    @click="kakaologin"
                    class="my-hover rounded shadow mb-3"
                    src="@/assets/img/kakao_login_medium_wide.png"
                    alt=""
                  />
                </div>
              </div>
            </template>
            <template>
              <div class="text-center text-muted mb-4">
                <small>Or sign up with credentials</small>
              </div>
              <form role="form">
                <base-input
                  placeholder="아이디"
                  addon-left-icon="ni ni-circle-08"
                  v-model="user.id"
                  class="mb-0"
                  :valid="idValid"
                >
                </base-input>
                <div v-if="!idValid & validation">
                  <div class="mb-2 text-gray">
                    <small>유효하지 않은 아이디 입니다.</small>
                  </div>
                </div>
                <base-input
                  type="password"
                  placeholder="비밀번호"
                  addon-left-icon="ni ni-lock-circle-open"
                  v-model="user.password"
                  class="mb-0 mt-3"
                  :valid="pwVaild"
                >
                </base-input>
                <div v-if="!pwVaild & validation" class="text-gray">
                  <small>숫자 + 영문 + 특수문자 8자 이상으로 구성해야 합니다.</small>
                </div>
                <base-input
                  type="text"
                  placeholder="주소"
                  addon-left-icon="ni ni-square-pin"
                  v-model="user.address"
                  class="mb-0 mt-3"
                  :valid="addressValid"
                >
                </base-input>
                <base-input
                  placeholder="이름"
                  addon-left-icon="ni ni-badge"
                  v-model="user.name"
                  class="mb-3 mt-3"
                  :valid="nameValid"
                >
                </base-input>
                <!-- <div v-if="!passwordValid">유효하지 않은 비밀번호 입니다.</div> -->

                <!-- 가능하면 할 부분 -> 비밀번호 보안도 표시해주기 (아마 정규표현식으로 하면 될듯?) -->
                <!-- <div class="text-muted font-italic">
									<small
										>Password strength:
										<span class="text-success font-weight-700">strong</span>
									</small>
								</div> -->
                <base-checkbox>
                  <span
                    >개인정보 수집 및 이용, 개인정보 제 3자 제공에 동의합니다.
                    <a href="#">Privacy Policy</a>
                  </span>
                </base-checkbox>
                <div class="text-center">
                  <base-button type="primary" class="my-4" v-on:click="regist"
                    >회원 가입</base-button
                  >
                </div>
              </form>
            </template>
          </card>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
import axios from "axios";

export default {
  data() {
    return {
      validation: false,
      user: {
        id: "",
        password: "",
        address: "",
        name: "",
      },
      passwordValid: false,
    };
  },
  computed: {
    idValid() {
      if (!this.validation) return null;
      return /^[A-Za-z0-9]+$/.test(this.user.id);
    },
    pwVaild() {
      if (!this.validation) return null;
      // passwordValid는 정규식, 숫자 / 영문 / 특수문자가 1개 이상 존재 + 8자이상
      return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d~!@#$%^&*()+|=]{8,20}$/.test(this.user.password);
    },
    addressValid() {
      if (!this.validation) return null;
      return /^.{1,}$/.test(this.user.address);
    },
    nameValid() {
      if (!this.validation) return null;
      return /^.{1,}$/.test(this.user.name);
    },
  },
  methods: {
    kakaologin() {
      //window.location.href="https://kauth.kakao.com/oauth/authorize?client_id=af19bb5087982aa80afec24c84c155ef&redirect_uri=http://localhost:8080/&response_type=code"
      window.location.href="https://kauth.kakao.com/oauth/authorize?client_id=af19bb5087982aa80afec24c84c155ef&redirect_uri=http://ssafy.ddns.net/&response_type=code"
    },
    regist() {
      this.validation = true;
      if (
        /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d~!@#$%^&*()+|=]{8,20}$/.test(this.user.password) &&
        /^[A-Za-z0-9]+$/.test(this.user.id) &&
        /^.{1,}$/.test(this.user.address) &&
        /^.{1,}$/.test(this.user.name)
      ) {
        axios
          .post(this.$store.getters.getBaseURL + "/user/register", {
            id: this.user.id,
            password: this.user.password,
            address: this.user.address,
            name: this.user.name,
          })
          .then((res) => {
            if (res.data.success) {
              alert("회원가입 성공");
              this.$router.push("/");
            } else {
              alert("회원가입 실패");
              console.log(res);
            }
          })
          .catch((error) => {
            alert("네트워크 에러");
            console.log(error);
          });
      }
    },
  },
};
</script>
<style>
.has-success::after {
  display: none !important;
}
.has-danger::after {
  display: none !important;
}
</style>

<style scoped>
.my-hover:hover {
  cursor: pointer;
}
</style>
