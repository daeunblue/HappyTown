<template>
  <b-container>
    <div class="chart-box">
      <b-card no-body class="overflow-hidden" style="max-width: 100%">
        <b-row no-gutters>
          <b-col md="3" class="border-right py-1">
            <b-card-body
              :title="cardTitle"
              class="d-flex justify-content-left pr-1"
            >
              <!-- <b-icon
                class="d-flex align-items-center"
                icon="exclamation-circle-fill"
                variant="danger"
              ></b-icon>
              <i class="ni ni-air-baloon" style="font-size:8px"></i> -->
              <icon
                :name="'ni ni-' + icon"
                :type="iconType"
                rounded
                class="mb-2 mt-0"
                style="
                  font-size: 10px;
                  position: absolute;
                  right: 13px;
                  top: 12px;
                "
              >
              </icon>
            </b-card-body>
            <b-card-text class="ml-3" v-html="cardText"> </b-card-text>
          </b-col>
          <b-col md="9">
            <div :class="myClass">
              <canvas
                class="px-2"
                ref="barChart"
                :height="chartHeight"
                :width="chartWidth"
              />
            </div>
          </b-col>
        </b-row>
      </b-card>
    </div>
  </b-container>
</template>

<script>
import { Chart, registerables } from 'chart.js';
import { mapGetters, mapState } from 'vuex';
import axios from 'axios';
Chart.register(...registerables);
Chart.defaults.interaction.intersect = false;
Chart.defaults.interaction.axis = 'x';

export default {
  props: {
    chartType: {},
    labelTitle: {},
    elementName: {},
    elementValue: {},
    requestUrl: {},
    cardTitle: {},
    cardText: {},
    icon: {},
    iconType: {},
    cborderRadius: {},
    chartHeight: {
      default: 255,
    },
    chartWidth: {
      default: 808,
    },
  },
  data() {
    return {
      myClass: '',
      myChart: {},
      isFirst: true,
      data: {
        labels: [],
        datasets: [
          {
            label: '',
            data: [],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
            pointHoverRadius: 5,
            hoverBackgroundColor: '#5e72e4',
            hoverBorderColor: '#5e72e4',
            borderRadius: 1,
          },
        ],
      },
      options: {
        responsive: false,
        scales: {
          y: {
            // beginAtZero: true,
          },
        },
        onClick: (e) => {
          let activePoints = this.myChart.getElementsAtEventForMode(
            e,
            'point',
            this.myChart.options,
          );
          if (activePoints) {
            if (activePoints[0]) {
              let index = activePoints[0].index;
              this.$router.push('/house?dongName=' + this.data.labels[index]);
            }
          }
        },
        onHover: (e) => {
          let activePoints = this.myChart.getElementsAtEventForMode(
            e,
            'point',
            this.myChart.options,
          );
          if (activePoints) {
            if (activePoints[0]) {
              // mouserOver
              this.myClass = 'mouse-over';
            } else {
              // mouseOut
              this.myClass = '';
            }
          }
        },
      },
    };
  },
  created() {
    this.data.datasets[0].label = this.labelTitle;
    this.createData();
  },
  computed: {
    ...mapState(['user']),
    ...mapGetters(['getGugunCode', 'getUserId', 'getUserCnt']),
  },
  watch: {
    getGugunCode: function () {
      this.createData();
    },
    getUserCnt: function () {
      // interestCnt가 바뀌면 차트 업데이트 하기
      //console.log('cnt값 변경됨');
      this.createData();
    },
  },
  methods: {
    async createData() {
      // 데이터 초기화
      this.data.labels = [];
      this.data.datasets[0].data = [];
      let url = this.requestUrl + this.getUserId;
      await axios
        .get(url, {
          headers: {
            'jwt-auth-token': this.$store.getters.getAccessToken,
          },
        })
        .then((res) => {
          //this.$store.commit('setUserCnt', res.data.length); // userInterestCnt 초기값
          let index = 0;

          res.data.forEach((element) => {
            // 데이터 삽입.

            this.data.labels[index] = element[this.elementName];
            this.data.datasets[0].data[index] = element[this.elementValue];
            index++;
          });
          // console.log("응답결과 ", this.data);
          this.createChart();
        })
        .catch((err) => {
          console.log(err);
        });
    },

    createChart() {
      //var grapharea = document.getElementById("myChart").getContext("2d");
      let grapharea = this.$refs.barChart;

      this.data.datasets[0].borderRadius = this.cborderRadius;
      if (this.isFirst) {
        this.myChart = new Chart(grapharea, {
          type: this.chartType,
          data: this.data,
          options: this.options,
        });
        // console.log(this.data);
      }
      // 두번째부터는 업데이트
      // 대체 왜안되는걸까 console에는 찍히는데 수정하려고하면 갑자기 속성이 없다는게 뭔지 모르겠다...진짜...

      this.myChart.update(); // Calling update now animates the position of March from 90 to 50.

      this.isFirst = false;
    },
  },
};
</script>

<style scoped>
.mouse-over {
  cursor: pointer;
}
</style>
