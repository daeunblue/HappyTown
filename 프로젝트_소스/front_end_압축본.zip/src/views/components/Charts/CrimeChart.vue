<template>
  <b-container>
    <div class="chart-box">
      <b-card no-body class="overflow-hidden" style="max-width: 100%">
        <b-row no-gutters>
          <b-col md="3">
            <b-card-body title="범죄율" class="d-flex justify-content-left">
              <b-icon
                class="d-flex align-items-center"
                icon="exclamation-circle-fill"
                variant="danger"
              ></b-icon>
            </b-card-body>
            <b-card-text class="ml-3">
              {{ 'selectedGu' }}
            </b-card-text>
          </b-col>
          <b-col md="9">
            <div class="chart">
              <canvas ref="barChart" id="chart" />
            </div>
          </b-col>
        </b-row>
      </b-card>
    </div>
  </b-container>
</template>

<script>
import { Chart, registerables } from 'chart.js';
import axios from 'axios';
import { mapGetters } from 'vuex';

Chart.register(...registerables);

export default {
  props: ['labelprop', 'columnName', 'valueName', 'requestURL'],
  data() {
    return {
      type: 'bar',
      crimeData: {},
      isFirst: true,
      myChart: null,
      data: {
        labels: [],
        datasets: [
          {
            label: '',
            data: [],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
          },
        ],
        options: {
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      },
    };
  },
  created() {
    this.data.datasets[0].label = this.labelprop;
  },
  computed: {
    ...mapGetters(['getGugunCode', 'getGugunName']),
  },
  watch: {
    getGugunCode: function () {
      this.createData();
    },
  },
  methods: {
    createData() {
      const url = 'http://localhost:8000/api/chart/crime/' + this.getGugunCode;
      let guAvg = '';
      //let cityAvg = "";
      axios
        .get(url, {
          headers: {
            'jwt-auth-token': this.$store.getters.getAccessToken,
          },
          // gugunCode: this.getGugunCode,
        })
        .then((res) => {
          this.crimeData = res.data;
          this.data.labels[0] = this.getGugunName + ' 평균';

          this.data.datasets[0].data[0] = res.data.crimeCntPerPopulation10000;
          guAvg = res.data.crimeCntPerPopulation10000;
        })
        .catch((err) => {
          console.log(err);
        });

      axios
        .get('http://localhost:8000/api/chart/crime/', {
          headers: {
            'jwt-auth-token': this.$store.getters.getAccessToken,
          },
        })
        .then((res) => {
          this.data.labels[1] = '서울시 평균';
          this.data.datasets[0].data[1] = res.data;
          //cityAvg = res.data;

          this.createChart(guAvg); //, cityAvg);
        })
        .catch((err) => {
          console.log(err);
        });
    },

    createChart(guAvg) {
      //, cityAvg) {
      // this.myChart = document.querySelector("#chart");
      // console.log("mychart: ", this.myChart);
      var grapharea = document.getElementById('chart').getContext('2d');

      if (this.isFirst) {
        // console.log("첫진입");
        this.myChart = new Chart(grapharea, {
          type: 'bar',
          data: this.data,
          options: this.options,
        });
      }
      // 두번째부터는 업데이트
      // 대체 왜안되는걸까 console에는 찍히는데 수정하려고하면 갑자기 속성이 없다는게 뭔지 모르겠음 진짜...
      // console.log("this data: " + guAvg + ", " + cityAvg);
      // console.log("first:" + this.myChart.data.datasets[0].data[0]);
      this.myChart.data.datasets[0].data[0] = guAvg;

      this.myChart.update(); // Calling update now animates the position of March from 90 to 50.

      this.isFirst = false;
    },

    destroyChart() {
      this.myChart.destroy();
    },
  },
};
</script>
