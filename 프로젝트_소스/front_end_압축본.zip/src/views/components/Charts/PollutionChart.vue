<template>
	<b-container>
		<div class="p-3 mt-4">
			<b-card no-body class="overflow-hidden" style="max-width: 100%">
				<b-row no-gutters>
					<b-col md="3">
						<b-card-body
							title="오염물질 배출 업소 수"
							class="d-flex justify-content-left"
						>
							<b-icon
								class="d-flex align-items-center"
								icon="exclamation-circle-fill"
								variant="danger"
							></b-icon>
						</b-card-body>
						<b-card-text class="ml-3">
							This is a wider card with supporting text as a natural lead-in to
							additional content. This content is a little bit longer.
						</b-card-text>
					</b-col>
					<b-col md="9">
						<div>
							<canvas ref="barChart" style="height: 30vh; width: 30vw" />
						</div>
					</b-col>
				</b-row>
			</b-card>
		</div>
	</b-container>
</template>

<script>
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

export default {
	data: () => ({
		type: "bar",
		data: {
			labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
			datasets: [
				{
					data: [12, 15, 3, 5, 2, 3],
					// data: [15, 5, 3],
					backgroundColor: [
						"rgba(255, 99, 132, 0.2)",
						"rgba(54, 162, 235, 0.2)",
						"rgba(255, 206, 86, 0.2)",
						"rgba(75, 192, 192, 0.2)",
						"rgba(153, 102, 255, 0.2)",
						"rgba(255, 159, 64, 0.2)",
					],
					borderColor: [
						"rgba(255, 99, 132, 1)",
						"rgba(54, 162, 235, 1)",
						"rgba(255, 206, 86, 1)",
						"rgba(75, 192, 192, 1)",
						"rgba(153, 102, 255, 1)",
						"rgba(255, 159, 64, 1)",
					],
					borderWidth: 1,
				},
			],
		},
		options: {
			responsive: false,
			scales: {
				y: {
					beginAtZero: true,
				},
			},
		},
	}),
	mounted() {
		this.createChart();
	},
	methods: {
		createChart() {
			new Chart(this.$refs.barChart, {
				type: "pie",
				data: this.data,
				options: this.options,
			});
		},
	},
};
</script>
