<template>
  <div>
    <div>
      <b-modal id="modal-1" title="HAPPY TOWN" ok-title="확인" ok-only>
        <p class="my-4">{{modaltext}}</p>
      </b-modal>
    </div>
    <div class="container">
      <card shadow>
        <div class="ml-5 mt-5">
          <router-link to="/salelist">
            <h3>
              <i class="ni ni-folder-17 mr-2 mt-1" style="font-size: 24px"></i>APT 매물 게시판
            </h3>
          </router-link>
          <div class="h6 font-weight-300"><i class="ni location_pin mr-2"></i>happy house</div>
        </div>

        <div class="container">
          <div class="form-group mt-3 p-3">
            <div class="alert alert-primary" role="alert">
              <h4 class="mb-0 ml-3 font-weight-600">
                {{ post.title }}
              </h4>
            </div>
            <p class="ml-3">
              작성자 :
              <span class="font-weight-bold">
                {{ post.regId }}
              </span>
            </p>
            <p class="ml-3">
              아파트이름 :
              <span class="font-weight-bold">
                {{ post.aptName }}
              </span>
            </p>
            <p class="ml-3">
              동이름 :
              <span class="font-weight-bold">
                {{ post.dongName }}
              </span>
            </p>
            <div class="border rounded p-3" style="min-height: 100px">
              <img :src="post.imgSrcUrl" alt="" class="" style="max-height: 400px" />
              <hr />
              {{ post.content }}
            </div>
            <!-- 댓글 -->
            <div class="row py-0 px-2 mt-2">
              <div class="col-2 align-self-center">{{ commentCnt }} 개의 댓글</div>
              <div class="col-10 justify-content-end">
                <div class="text-lg-right align-self-lg-end">
                  <div v-if="$store.getters.getUserName == post.regId || $store.getters.getUserId == 'admin'" class="pt-2">
                    <base-button type="danger" size="sm" class="float-right" @click="del"
                      >삭제</base-button
                    >
                  </div>
                </div>
              </div>
            </div>
            <hr />
            <div v-for="(comment, index) in comments" :key="index">
              <!-- <div> -->
              <div class="alert alert-secondary row mx-1" role="alert">
                <div class="col-2 border-right border-white">
                  {{ comment.id }}
                </div>
                <div class="col-auto">
                  {{ comment.content }}
                </div>
                <div style="position: absolute; top: 6px; right: 10px">
                  <base-button
                    v-if="$store.getters.getUserName == comment.id || $store.getters.getUserId == 'admin'"
                    type="danger"
                    size="sm"
                    class="float-right small"
                    @click="commentDelete(comment.no)"
                    >삭제</base-button
                  >
                  <!-- <base-button>삭제</base-button> -->
                </div>
              </div>
            </div>

            <!-- <div v-if="$store.getters.getUserId"> -->
            <div>
              <div class="row mx-1">
                <textarea
                  style="resize: none"
                  class="form-control"
                  id="exampleFormControlTextarea1"
                  rows="2"
                  placeholder="댓글 내용을 입력하세요..."
                  v-model="content"
                ></textarea>
              </div>
              <div class="row justify-content-end px-2">
                <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
                  <div class="mt-2">
                    <base-button type="primary" size="sm" class="" @click="sendComment"
                      >등록</base-button
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseFinalSeoul11FrontKimdaeunKimdaeheeSaleDetail",
  data() {
    return {
      modaltext: '',
      content: "",
      post: {},
      comments: [],
    };
  },

  mounted() {
    this.$store.dispatch("getNoti");
    const query = this.$route.query;
    ai.get(this.$store.getters.getBaseURL + "/api/aptsale/" + query.no, {
      headers: {
        "jwt-auth-token": this.$store.getters.getAccessToken,
      },
    })
      .then((res) => {
        this.post = res.data;
      })
      .catch((error) => {
        alert("네트워크 에러 or token없음");
        console.log(error);
      });

    ai.get("/comment/" + (parseInt(query.no) + 10000), {
      headers: {
        "jwt-auth-token": this.$store.getters.getAccessToken,
      },
    })
      .then((res) => {
        this.comments = res.data;
      })
      .catch((error) => {
        alert("네트워크 에러 or token없음");
        console.log(error);
      });
  },

  computed: {
    commentCnt() {
      return this.comments.length;
    },
  },

  methods: {
    modal(text){
      this.modaltext = text;
      this.$bvModal.show("modal-1");
    },
    modify() {},
    del() {
      const query = this.$route.query;
      ai.delete("/aptsale/" + query.no, {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          console.log(res);
          this.modal("삭제되었습니다");
          this.$router.push("/salelist");
        })
        .catch((error) => {
          console.log(error);
        });
    },
    commentDelete(no) {
      ai.delete("/comment/" + no, {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          if (res.data == 1) {
            // this.$router.push("/boarddetail?no="+query.no);
            for (let i = 0; this.comments.length; i++) {
              if (this.comments[i].no === no) {
                this.comments.splice(i, 1);
                break;
              }
            }
          } else {
            alert(res);
            console.log(res);
          }
        })
        .catch((error) => {
          alert("네트워크 에러 or 토큰 없음");
          console.log(error);
        });
    },
    sendComment() {
      const query = this.$route.query;
      if(this.content){
        ai.post(
          "/comment/" + (parseInt(query.no) + 10000),
          {
            id: this.$store.getters.getUserName,
            content: this.content,
          },
          {
            headers: {
              "jwt-auth-token": this.$store.getters.getAccessToken,
            },
          }
        )
          .then((res) => {
            if (res.data == 1) {
              // this.$router.push("/boarddetail?no="+query.no);
              this.$router.go();
            } else {
              alert(res);
              console.log(res);
            }
          })
          .catch((error) => {
            alert("네트워크 에러 or 토큰 없음");
            console.log(error);
          });
      }
      else {
        this.modal("댓글 내용을 작성하세요");
      }
    },
  },
};
</script>

<style scoped></style>
