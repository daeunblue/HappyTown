<template>
  <div>
    <div class="container">
      <card shadow class="card-profile" no-body>
        <div class="text-center mt-4">
          <h3><i class="ni ni-folder-17 mr-2" style="font-size: 24px"></i>APT 매물 목록</h3>
          <div class="h6 font-weight-300">
            <i class="ni location_pin mr-2"></i>{{ this.$store.state.serviceName }}
          </div>
          <div><i class="ni education_hat mr-2"></i>매물 등록은 회원만 가능합니다.</div>
        </div>
        <div class="container mt-3 px-4">
          <div class="row" style="white-space: nowrap">
            <div v-for="(item, index) in getPage" :key="index" class="col-4 p-2">
              <div class="card card-lift--hover shadow" style="max-height: 415px">
                <img
                  :src="item.imgSrcUrl"
                  @click="detail(item)"
                  alt=""
                  class="my-hover card-img-top"
                  style="height: 245px"
                />
                <div class="card-body">
                  <div style="overflow-x: hidden">
                    <h5 class="card-title">{{ item.aptName }}</h5>
                    <p class="card-text">
                      {{ item.title }}
                    </p>
                  </div>
                  <router-link
                    @click.native="addInterestDong(item)"
                    :to="'/house?dongName=' + item.dongName"
                    class="btn btn-primary"
                    >{{ item.dongName }}</router-link
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="container" style="position: relative">
            <div id="pagination" class="pl-1 pt-1">
              <base-pagination
                class="mt-2"
                align="center"
                :page-count="getTotalPagesCnt"
                v-model="pagination.pageNo"
              ></base-pagination>
            </div>
            <div
              v-if="$store.getters.getUserId"
              class=""
              style="position: absolute; top: 10px; right: 15px"
            >
              <base-button type="info" size="sm" class="mr-4" @click="saleWrite"
                >매물 등록하기</base-button
              >
            </div>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";
import { mapGetters } from "vuex";

export default {
  name: "HappyhouseVueFrontSaleList",

  data() {
    return {
      pagination: {
        itemPerPage: 6,
        pageNo: 1,
      },
      items: [],

      fields: [
        {
          key: "no",
          label: "글번호",
        },
        {
          key: "title",
          label: "제목",
        },
        {
          key: "regId",
          label: "글쓴이",
        },
        {
          key: "viewCount",
          label: "조회수",
        },
      ],
      dongCode: "",
    };
  },

  mounted() {
    this.$store.dispatch("getNoti");
    this.getList();
  },
  computed: {
    getPage() {
      return this.items.slice(
        this.pagination.itemPerPage * (this.pagination.pageNo - 1),
        this.pagination.itemPerPage * this.pagination.pageNo
      );
    },
    getTotalPagesCnt() {
      return parseInt((this.items.length - 1) / this.pagination.itemPerPage) + 1;
    },

    ...mapGetters(["getUserId"]),
  },

  methods: {
    detail(item) {
      this.$router.push("/saledetail?no="+item.no);
    },
    saleWrite() {
      this.$router.push("/salewrite");
    },
    getList() {
      ai.get("/aptsale", {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          this.items = res.data;
        })
        .catch((error) => {
          alert("네트워크 오류 or 토큰없음");
          console.log(error);
        });
    },

    // addInterestDong -> 클릭시 userId + dongCode 를 post요청으로 user_interest_dong 정보에 추가
    async addInterestDong(item) {
      try {
        // console.log(item);
        // console.log('add: ' + this.getUserId + ', ' + item.dongName);
        // 동이름으로 동코드 반환받고 -> 해당 정보로 관심 동 등록
        // let url = this.$store.getters.getBaseURL + "/api/house/find/" + item.dongName;
        // // console.log(url);
        // await ai
        //   .get(url, {
        //     headers: {
        //       "jwt-auth-token": this.$store.getters.getAccessToken,
        //     },
        //   })
        //   .then((res) => {
        //     // console.log('동 코드 ' + res.data);
        //     this.dongCode = res.data;
        //     // alert(item.dongName + '관심 등록 성공!');
        //     console.log(this.dongCode);
        //   })
        //   .catch((err) => {
        //     alert("네트워크 에러 or 로그인 정보가 유효하지 않습니다.");
        //     console.log(err);
        //   });
      } catch (err) {
        alert("네트워크 에러 or 로그인 정보가 유효하지 않습니다.");
        console.log(err);
        console.log(item);
      }

      // this.url =
      //   this.$store.getters.getBaseURL +
      //   "/api/interest/dong/" +
      //   this.getUserId +
      //   "/" +
      //   this.dongCode;
      // await ai
      //   .post(this.url, {
      //     headers: {
      //       "jwt-auth-token": this.$store.getters.getAccessToken,
      //     },
      //   })
      //   .then((res) => {
      //     console.log(res);
      //     alert(item.dongName + "관심 등록 성공!");
      //   })
      //   .catch((err) => {
      //     if (err.response.status == 500) {
      //       alert("이미 찜했습니다.(" + item.dongName + ")");
      //     } else {
      //       alert("네트워크 에러 or 로그인 정보가 유효하지 않습니다.");
      //       console.log(err);
      //     }
      //   });
    },
  },
};
</script>

<style scoped>
.my-hover:hover {
  cursor: pointer;
}
</style>
