<template>
  <div>
    <div>

      <b-modal id="modal-1" title="HAPPY TOWN" ok-title="확인" ok-only :okDisabled="send">
        <p class="my-4">{{modaltext}}</p>
      </b-modal>
    </div>
    <div class="container">
      <card shadow class="card-profile" no-body>
        <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
          <div class="card-profile-actions py-4 mt-lg-0">
            <base-button type="info" size="sm" class="mr-4" @click="write">등록하기</base-button>
            <base-button
              type="default"
              size="sm"
              class="float-right"
              @click="$router.push('/salelist')"
              >취소</base-button
            >
          </div>
        </div>
        <div class="text-center mt-5">
          <h3><i class="ni ni-chat-round mr-2" style="font-size: 20px"></i>APT 매물 등록</h3>
        </div>
        <div class="m-3">
          <div class="form-group mt-3">
            <form>
              <div class="mb-2">제목 :</div>
              <input
                type="text"
                class="form-control mb-3"
                placeholder="제목을 입력하세요..."
                v-model="title"
              />
              <div class="mb-2">지역정보 :</div>
                      <div id="drop-down" class="container mb-2">
                        <div class="row">
                          <b-dropdown
                            id="dropdown-1"
                            :text="dropdown.sidoName"
                            class="col-4 px-1"
                            size="sm"
                            block
                            :no-caret="!dropdown.sidoCaret"
                          >
                            <b-dropdown-item
                              v-for="(item, index) in dropdown.sidoList"
                              :key="index"
                              @click="sidoSelect(item.name, item.code)"
                              >{{ item.name }}</b-dropdown-item
                            >
                          </b-dropdown>
                          <b-dropdown
                            id="dropdown-2"
                            :text="dropdown.gugunName"
                            class="col-4 px-1"
                            size="sm"
                            block
                            :no-caret="!dropdown.gugunCaret"
                          >
                            <b-dropdown-item
                              v-for="(item, index) in dropdown.gugunList"
                              :key="index"
                              @click="gugunSelect(item.name, item.code)"
                              >{{ item.name }}</b-dropdown-item
                            >
                          </b-dropdown>
                          <b-dropdown
                            id="dropdown-3"
                            :text="dropdown.dongName"
                            class="col-4 px-1"
                            size="sm"
                            block
                            :no-caret="!dropdown.dongCaret"
                          >
                            <b-dropdown-item
                              v-for="(item, index) in dropdown.dongList"
                              :key="index"
                              @click="dongSelect(item.name, item.code)"
                              >{{ item.name }}</b-dropdown-item
                            >
                          </b-dropdown>
                        </div>
                      </div>
              <div class="mb-2">아파트이름 :</div>
              <input
                type="text"
                class="form-control mb-3"
                placeholder="아파트이름을 입력하세요..."
                v-model="aptName"
              />
              <div class="mb-2">내용 :</div>
              <textarea
                class="form-control mb-3"
                id="exampleFormControlTextarea1"
                rows="5"
                placeholder="내용을 입력하세요..."
                v-model="content"
              ></textarea>
              <div class="mb-2">APT 사진 :</div>
              <input
                @change="fileSelected()"
                type="file"
                ref="aptimage"
                name="uploadfile"
                accept=".jpg, .jpeg, .png"
              />
              <br />
              <div class="mt-3">
                <img :src="img" class="shadow" style="max-width: 400px" alt="" />
              </div>
            </form>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import { getSidoList, getGugunList, getDongList } from "@/js/locationCode.js";
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseVueFrontSaleWrite",

  data() {
    return {
      modaltext: '',
      send: false,
      dropdown: {
        sidoCaret: true,
        sidoName: "시/도",
        sidoCode: "",
        sidoList: [],
        gugunCaret: true,
        gugunName: "구/군",
        gugunCode: "",
        gugunList: [],
        dongCaret: true,
        dongName: "동",
        dongCode: "",
        dongList: [],
      },
      img: "",
      imgfile: "",
      title: "",
      content: "",
      aptName: "",
      dongName: "",
    };
  },

  mounted() {
    getSidoList(this.dropdown);
  },

  methods: {
    modal(text){
      this.modaltext = text;
      this.$bvModal.show("modal-1");
    },
    sidoSelect(sidoName, sidoCode) {
      this.dropdown.sidoName = sidoName;
      this.dropdown.sidoCode = sidoCode;
      this.dropdown.sidoCaret = false;
      getGugunList(this.dropdown);
    },
    gugunSelect(gugunName, gugunCode) {
      this.dropdown.gugunName = gugunName;
      this.dropdown.gugunCode = gugunCode;
      this.dropdown.gugunCaret = false;
      getDongList(this.dropdown);
    },
    dongSelect(dongName, dongCode) {
      this.dropdown.dongName = dongName;
      this.dropdown.dongCode = dongCode;
      this.dropdown.dongCaret = false;
      // 지도 이동
      this.dongName = dongName;
    },
    fileSelected() {
      this.imgfile = this.$refs.aptimage.files[0];

      let reader = new FileReader();
      reader.onload = (e) => {
        this.img = e.target.result;
      };

      reader.readAsDataURL(this.imgfile);
    },
    board() {
      this.$router.push("board");
    },
    write() {
      if(this.imgfile && this.title && this.aptName && this.dongName){
        if(!this.send) {
          this.send = true;
          const formData = new FormData();
          formData.append("imgfile", this.imgfile);
          formData.append("title", this.title);
          formData.append("content", this.content);
          formData.append("aptName", this.aptName);
          formData.append("regId", this.$store.getters.getUserName);
          formData.append("dongName", this.dongName);
          this.modal("잠시 기다려주세요 등록중입니다. 고화질 사진은 업로드가 오래걸릴 수 있습니다");
    
          this.$store.commit("setWait", {wait:true});
          ai.post("/aptsale", formData, {
            headers: {
              "Content-Type": "multipart/form-data",
              "jwt-auth-token": this.$store.getters.getAccessToken,
            },
          })
            .then((res) => 
            {
              this.$store.commit("setWait", {wait:false});
              console.log(res);
              this.$router.push("/salelist");
            })
            .catch((error) => {
              this.$store.commit("setWait", {wait:false});
              console.log(error);
            });
        }
        else {
          this.modal("잠시 기다려주세요 등록중입니다.");
        }
      }
      else {
        this.modal("항목을 모두 채워주세요.(사진 포함)");
      }
    },
  },
};
</script>

<style scoped>
::v-deep .dropdown-menu {
  max-height: 330px;
  overflow-y: auto;
}
</style>
