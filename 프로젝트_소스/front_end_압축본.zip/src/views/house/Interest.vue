<template>
  <div>
    <div class="container">
      <card shadow class="card-profile" no-body>
        <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
          <div class="card-profile-actions py-5 mt-lg-0"></div>
        </div>
        <div class="text-center mt-5">
          <h3>
            <b-icon-house-fill></b-icon-house-fill> 관심 APT
            <b-icon-house-fill></b-icon-house-fill>
          </h3>
          <div class="h6 font-weight-300">
            <i class="ni location_pin mr-2"></i>happy house
          </div>

          <div>
            <i class="ni education_hat mr-2"></i> {{ user.name }}님이 관심있어
            하는 아파트에 대한 정보를 <br />
            정리해 드릴게요 !
          </div>
        </div>
        <div class="container mt-3">
          <b-table hover :items="items" :fields="fields"
            ><template v-slot:cell(delete)="{ item }">
              <span><b-btn @click="deleteInterest(item)">Delete</b-btn></span>
            </template>
            <!-- <template slot="삭제" slot-scope="data">
              <b-button size="sm" @click="deleteInterest" class="mr-2">
                삭제
              </b-button>
            </template> -->
          </b-table>
          <div>
            <b-table
              :items="resultItems"
              :fields="resultFields"
              :sort-by.sync="sortBy"
              :sort-desc.sync="sortDesc"
              responsive="sm"
            ></b-table>
          </div>
        </div>
        <div>
          <interest-chart
            ref="InterestChart"
            card-title="범죄 지수"
            card-text="<p>늦은 시간에도 안심하고 <br>돌아다닐 수 있는  <br>안전한 동네를 찾는 여러분께 <br>동별 5대 범죄 발생 수를<br> 알려드릴게요"
            label-title="인구수 10,000명당 범죄 발생 수 (건)"
            chart-type="bar"
            :cborderRadius="Number.MAX_VALUE"
            :request-url="this.$store.getters.getBaseURL + '/api/uChart/'"
            element-name="dongName"
            element-value="crimeCntPerPopulation10000"
            icon="single-02"
            icon-type="danger"
          ></interest-chart>
          <interest-chart
            ref="InterestChart"
            card-title="실 거래가"
            card-text="동네별 실제 거래 가격 <br>찾느라 힘드셨죠? <br>관심 있는 동네들의 <br>아파트 실거래가를 <br> 차트로 한 번에 알려드릴게요!"
            label-title="최근 4개년 평균 평당 거래가 (만 원)"
            chart-type="line"
            :request-url="this.$store.getters.getBaseURL + '/api/uChart/deal/'"
            element-name="dongName"
            element-value="avgDealAmountPerArea"
            icon="building"
            icon-type="success"
          >
          </interest-chart>
          <interest-chart
            ref="InterestChart"
            card-title="학원/교육 지수"
            card-text="<p><b>맹모삼천지교(孟母三遷之敎)</b> <br>라는 말이 있듯,  <br>우리 아이의 10대를 책임질 <br> 동네의 교육지수도  <br> 차트로 한눈에 보여드릴게요!"
            label-title="학원, 교육시설 개수"
            chart-type="line"
            :request-url="
              this.$store.getters.getBaseURL + '/api/uChart/store/학문/'
            "
            element-name="dongName"
            element-value="kindCnt"
            icon="hat-3"
            icon-type="info"
          >
          </interest-chart>
          <div class="row px-3">
            <interest-chart
              ref="InterestChart"
              class="col-6"
              card-title="대기오염 배출업체"
              card-text="<p>장기적·지속적 노출시<br> 폐 질환 등을 <br>유발하는<br> 유해한<br> 미세먼지!<br> 해당 동네의 <br> 대기오염 <br> 지수입니다"
              label-title="대기오염 배출 업체 수"
              chart-type="doughnut"
              :request-url="this.$store.getters.getBaseURL + '/api/uChart/'"
              element-name="dongName"
              element-value="polluterCnt"
              icon=""
              icon-type=""
              chartWidth="370"
              :chartHeight="450"
            >
            </interest-chart>
            <interest-chart
              ref="InterestChart"
              class="col-6"
              card-title="공원"
              card-text="여러분의 <br>여가시간을 <br>상쾌하게 <br>보낼 수 있게<br> 공원 정보를 <br>보여드릴게요"
              label-title="공원 개수"
              chart-type="bar"
              :cborderRadius="Number.MAX_VALUE"
              :request-url="this.$store.getters.getBaseURL + '/api/uChart/'"
              element-name="dongName"
              element-value="parkCnt"
              icon=""
              icon-type=""
              chartWidth="370"
              :chartHeight="450"
            >
            </interest-chart>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import { Chart, registerables } from 'chart.js';
import axios from 'axios';
import { mapGetters, mapMutations, mapState } from 'vuex';
import InterestChart from '@/views/components/Charts/InterestChart.vue';

Chart.register(...registerables);
export default {
  components: { InterestChart },
  data() {
    return {
      sortBy: 'dealRate',
      sortDesc: false,

      items: [],
      fields: [
        {
          key: 'aptName',
          label: '아파트명',
        },
        {
          key: 'avgAmount',
          label: '평균 거래가',
        },
        {
          key: 'buildYear',
          label: '건축년도',
        },
        {
          key: 'delete',
          label: '삭제',
        },
      ],

      resultItems: [],
      resultFields: [
        {
          key: 'crimeRate',
          label: '범죄지수',
        },
        {
          key: 'dealRate',
          label: '거래지수',
        },
        {
          key: 'pollutionRate',
          label: '오염지수',
        },
        {
          key: 'medicalRate',
          label: '의료지수',
        },
      ],

      citys: {},
      selectedCity: {
        code: '',
        name: '',
      },
      selectedGu: {
        code: '',
        name: '',
      },
      gus: [],
      val: '',
      gugunCode: '',
    };
  },
  created() {},

  computed: {
    ...mapState(['user']),
    ...mapGetters(['getUserId', 'getUserCnt']),
    ...mapMutations(['addUserCnt']),
  },
  mounted() {
    this.$store.dispatch('getNoti');
    this.listLoad();
  },
  methods: {
    async listLoad() {
      //console.log('관심 APT 정보 불러오기');
      try {
        const res = await axios.get(
          this.$store.getters.getBaseURL + '/api/interest/' + this.getUserId,
          {
            headers: {
              'jwt-auth-token': this.$store.getters.getAccessToken,
            },
          },
        );
        // console.log(res);
        this.items = res.data;

        for(let item of this.items){
          //return Math.round(parseInt(dealAmount.replace(",", "")) / 1000) / 10;
          item.avgAmount =  (Math.round(item.avgAmount / 1000) / 10) + '억';
          item.aptName = '['+item.dong+'] - '+item.aptName;

        }
      } catch (err) {
        alert('네트워크 에러 or Token이 유효하지 않음');
        console.log(err);
      }
    },

    async deleteInterest(item) {
      //console.log(item);
      //console.log('관심 APT 삭제');
      //console.log(this.getUserId + ', ' + item.aptCode);
      // console.log(this.getUserCnt);
      try {
        const res = await axios.delete(
          this.$store.getters.getBaseURL +
            '/api/interest/' +
            String(item.aptCode) +
            '/' +
            this.getUserId,
          {
            headers: {
              'jwt-auth-token': this.$store.getters.getAccessToken,
            },
          },
        );
        if(res.data){
          this.$store.commit('addUserCnt', this.items.length);
          this.listLoad();
        }
      } catch (err) {
        alert('네트워크 에러 or Token이 유효하지 않음');
        console.log(err);
      }
    },
  },
};
</script>
<style>
p {
  padding: 0px;
}
</style>
