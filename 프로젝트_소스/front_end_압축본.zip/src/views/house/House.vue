<template>
  <div>
    <div>

      <b-modal id="modal-1" title="HAPPY TOWN" ok-title="확인" ok-only>
        <p class="my-4">{{modaltext}}</p>
      </b-modal>
    </div>
    <div class="container">
      <card shadow class="card-profile" no-body>
        <div class="text-center">
          <!-- 필요할지도 모르는 상단 헤더 -->
        </div>
        <!-- 지도 공간 -->
        <div class="p-1">
          <div id="map" class="bg-yellow card">
            <!-- 카카오 지도 -->
            <div id="map-content" class="text-center" style="font-size: 150px">
              <div id="map"></div>
            </div>
            <!-- 좌측 정보창 -->
            <div id="house-list" class="shadow px-1">
              <div>
                <div id="top-box" class="pt-2">
                  <div class="border-bottom border-dark pb-1">
                    <base-alert class="h5 bg-default text-center py-1 mx-1"> APT 목록 </base-alert>
                    <div class="mt-1">
                      <!-- 드롭다운 -->
                      <div id="drop-down" class="container mb-2">
                        <div class="row">
                          <b-dropdown
                            id="dropdown-1"
                            :text="dropdown.sidoName"
                            class="col-4 px-1"
                            size="sm"
                            block
                            :no-caret="!dropdown.sidoCaret"
                          >
                            <b-dropdown-item
                              v-for="(item, index) in dropdown.sidoList"
                              :key="index"
                              @click="sidoSelect(item.name, item.code)"
                              >{{ item.name }}</b-dropdown-item
                            >
                          </b-dropdown>
                          <b-dropdown
                            id="dropdown-2"
                            :text="dropdown.gugunName"
                            class="col-4 px-1"
                            size="sm"
                            block
                            :no-caret="!dropdown.gugunCaret"
                          >
                            <b-dropdown-item
                              v-for="(item, index) in dropdown.gugunList"
                              :key="index"
                              @click="gugunSelect(item.name, item.code)"
                              >{{ item.name }}</b-dropdown-item
                            >
                          </b-dropdown>
                          <b-dropdown
                            id="dropdown-3"
                            :text="dropdown.dongName"
                            class="col-4 px-1"
                            size="sm"
                            block
                            :no-caret="!dropdown.dongCaret"
                          >
                            <b-dropdown-item
                              v-for="(item, index) in dropdown.dongList"
                              :key="index"
                              @click="dongSelect(item.name, item.code)"
                              >{{ item.name }}</b-dropdown-item
                            >
                          </b-dropdown>
                        </div>
                      </div>
                      <!-- 필터 -->
                      <div id="filter" class="mx-1">
                        <div class="bg-white px-2 pt-2 pb-1 mb-1 rounded text-center">
                          <div class="row">
                            <div class="col-4 text-left bold">평균거래가</div>
                            <div class="col-3 p-0">
                              <span class="mycolor">{{ minPrice }}</span
                              >억
                            </div>
                            <div class="col-1 p-0">~</div>
                            <div class="col-3 p-0">
                              <span class="mycolor">{{ maxPrice }}</span
                              >억
                            </div>
                          </div>
                          <base-slider
                            v-model.lazy="sliders.slider1"
                            :range="{ min: 0, max: 20.0 }"
                            @change="test"
                            :lazy="true"
                          ></base-slider>
                        </div>
                        <div class="bg-white px-2 pt-2 pb-1 mb-1 rounded text-center">
                          <div class="row">
                            <div class="col-4 text-left">평수</div>
                            <div class="col-3 p-0">
                              <span class="mycolor">{{ minArea }}</span
                              >평
                            </div>
                            <div class="col-1 p-0">~</div>
                            <div class="col-3 p-0">
                              <span class="mycolor">{{ maxArea }}</span
                              >평
                            </div>
                          </div>
                          <base-slider
                            v-model="sliders.slider2"
                            :range="{ min: 5, max: 50 }"
                          ></base-slider>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div id="bottom-box" class="h-100">
                  <div class="h-100">
                    <!-- 아파트 리스트 -->
                    <b-list-group id="group" class="mt-1 p-1">
                      <b-list-group-item
                        class="border"
                        href="#"
                        v-for="(item, index) in getHousePage"
                        :key="index"
                        @click="aptClick(item)"
                        @mouseover="mouseover(item)"
                        @mouseout="mouseout"
                        >{{ item.aptName }}
                        <span class="text-right" style="position: absolute; right: 10px">
                          <b-button
                            @click="addInterestDong(item)"
                            class="btn dong-btn bg-gray text-white rounded p-1"
                            style="font-size: 12px"
                            v-b-tooltip.hover="{ variant: 'info' }"
                            title="관심동으로 설정해보세요!"
                          >
                            {{ item.dong }}
                          </b-button>
                        </span>
                      </b-list-group-item>
                    </b-list-group>

                    <!-- 페이징 -->
                    <div id="pagination" class="pl-1 pt-1">
                      <base-pagination
                        class="mt-2"
                        align="center"
                        :page-count="getHouseTotalPagesCnt"
                        v-model="pagination.pageNo"
                      ></base-pagination>
                    </div>
                    <img src="" alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";
import { getSidoList, getGugunList, getDongList } from "@/js/locationCode.js";
import { mapGetters } from "vuex";
// import EventBus from '@/js/eventBus';

export default {
  name: "HappyhouseVueFrontBoard",

  data() {
    return {
      modaltext: '',
      dropdown: {
        sidoCaret: true,
        sidoName: "시/도",
        sidoCode: "",
        sidoList: [],
        gugunCaret: true,
        gugunName: "구/군",
        gugunCode: "",
        gugunList: [],
        dongCaret: true,
        dongName: "동",
        dongCode: "",
        dongList: [],
      },
      pagination: {
        itemPerPage: 8,
        pageNo: 1,
      },
      sliders: {
        slider1: [1.2, 14.5],
        slider2: [14, 47],
      },
      dealinfo: {
        selected: 2020,
        options: [
          { item: 2020, name: "2020년" },
          { item: 2019, name: "2019년" },
          { item: 2018, name: "2018년" },
          { item: 2017, name: "2017년" },
          { item: 2016, name: "2016년" },
          { item: 2015, name: "2015년" },
        ],
      },
      houseList: [],
      filteredList: [],
      kakaoMap: {
        mouseOverOverlayList: [],
        selectedItem: null,
        mapObject: null,
        geocoder: null,
        customOverlay: null,
        clickedOverlay: null,
        normalMarkerImg: null,
        selectedMarkerImg: null,
      },
    };
  },
  computed: {
    ...mapGetters(["getUserId"]),
    getHouseTotalPagesCnt() {
      return parseInt((this.filteredList.length - 1) / this.pagination.itemPerPage) + 1;
    },
    getHousePage() {
      return this.filteredList.slice(
        this.pagination.itemPerPage * (this.pagination.pageNo - 1),
        this.pagination.itemPerPage * this.pagination.pageNo
      );
    },
    minPrice() {
      return Math.round(this.sliders.slider1[0] * 10) / 10;
    },
    maxPrice() {
      return Math.round(this.sliders.slider1[1] * 10) / 10;
    },
    minArea() {
      return Math.round(this.sliders.slider2[0]);
    },
    maxArea() {
      return Math.round(this.sliders.slider2[1]);
    },
  },
  mounted() {
    this.$store.dispatch("getNoti");

    getSidoList(this.dropdown);

    if (window.kakao && window.kakao.maps) {
      this.initMap();
    } else {
      const script = document.createElement("script");
      /* global kakao */
      script.onload = () => kakao.maps.load(this.initMap);
      script.src =
        "//dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=e25c2c9b21ebfb8d012addbb604adc9a&libraries=services,clusterer,drawing";
      document.head.appendChild(script);
    }

    let handlers = document.getElementsByClassName("noUi-handle");
    for (let item of handlers) {
      item.addEventListener("click", this.housefilter);
    }
  },
  methods: {
    housefilter() {
      this.filteredList = [];
      let minPrice = this.sliders.slider1[0] * 10000;
      let maxPrice = this.sliders.slider1[1] * 10000;
      let minArea = this.sliders.slider2[0] * 3.3;
      let maxArea = this.sliders.slider2[1] * 3.3;
      for (let item of this.houseList) {
        if (
          minArea <= parseInt(item.maxArea) &&
          parseInt(item.minArea) <= maxArea &&
          minPrice <= item.avgAmount &&
          item.avgAmount <= maxPrice
        ) {
          this.filteredList.push(item);
        }
      }
      this.setMarker(this.filteredList);
      if (this.kakaoMap.clickedOverlay) {
        this.kakaoMap.clickedOverlay.setMap(null);
        this.kakaoMap.clickedOverlay.setMap(this.kakaoMap.mapObject);
      }
    },
    modal(text){
      this.modaltext = text;
      this.$bvModal.show("modal-1");
    },

    test() {
      console.log("test");
    },
    initMap() {
      const container = document.getElementById("map");
      const options = {
        center: new kakao.maps.LatLng(33.450701, 126.570667),
        level: 7,
      };

      // parameter 받았을 경우
      let query = this.$route.query;
      let location = "서울시";
      if (query.dongName) {
        location = query.dongName.split(" ")[0];
        options.level = 5;
      }

      //지도 객체를 등록합니다.
      //지도 객체는 반응형 관리 대상이 아니므로 initMap에서 선언합니다.
      this.kakaoMap.mapObject = new kakao.maps.Map(container, options);
      this.kakaoMap.geocoder = new kakao.maps.services.Geocoder();

      this.kakaoMap.geocoder.addressSearch(location, (result, status) => {
        if (status === kakao.maps.services.Status.OK) {
          var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
          this.kakaoMap.mapObject.setCenter(coords);
          // apt 정보 load
          this.loadHouseInfo();
        }
      });

      let imageOption = { offset: new kakao.maps.Point(15, 30) };
      //let imageSize = new kakao.maps.Size(60, 93);
      let imageSize = new kakao.maps.Size(30, 46);
      this.kakaoMap.normalMarkerImg = new kakao.maps.MarkerImage(
        require("@/assets/img/marker_1.png"),
        imageSize,
        imageOption
      );
      this.kakaoMap.selectedMarkerImg = new kakao.maps.MarkerImage(
        require("@/assets/img/marker_2.png"),
        imageSize,
        imageOption
      );

      // 지도 이동 이벤트 등록
      kakao.maps.event.addListener(this.kakaoMap.mapObject, "dragend", () => {
        this.loadHouseInfo();
      });
      // 지도 줌 변경 이벤트 등록
      kakao.maps.event.addListener(this.kakaoMap.mapObject, "zoom_changed", () => {
        this.loadHouseInfo();
      });
    },
    sidoSelect(sidoName, sidoCode) {
      this.dropdown.sidoName = sidoName;
      this.dropdown.sidoCode = sidoCode;
      this.dropdown.sidoCaret = false;
      getGugunList(this.dropdown);
    },
    gugunSelect(gugunName, gugunCode) {
      this.dropdown.gugunName = gugunName;
      this.dropdown.gugunCode = gugunCode;
      this.dropdown.gugunCaret = false;
      getDongList(this.dropdown);
    },
    dongSelect(dongName, dongCode) {
      this.dropdown.dongName = dongName;
      this.dropdown.dongCode = dongCode;
      this.dropdown.dongCaret = false;
      // console.log(dongName, dongCode);
      // 지도 이동
      this.kakaoMap.geocoder.addressSearch(dongName, (result, status) => {
        if (status === kakao.maps.services.Status.OK) {
          var coords = new kakao.maps.LatLng(result[0].y, result[0].x);
          this.kakaoMap.mapObject.setCenter(coords);
          this.kakaoMap.mapObject.setLevel(5);
          this.loadHouseInfo();
        }
      });
    },
    loadHouseInfo() {
      let map = this.kakaoMap.mapObject;
      // 지도의 현재 영역을 얻어옵니다
      var bounds = map.getBounds();
      // 영역의 남서쪽 좌표를 얻어옵니다
      var swLatLng = bounds.getSouthWest();
      // 영역의 북동쪽 좌표를 얻어옵니다
      var neLatLng = bounds.getNorthEast();

      const reauestUrl =
        "/house?minLat=" +
        swLatLng.Ma +
        "&maxLat=" +
        neLatLng.Ma +
        "&minLng=" +
        swLatLng.La +
        "&maxLng=" +
        neLatLng.La;
      ai.get(reauestUrl, {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          // 기존 마커 삭제
          // if (this.houseList) {
          //   this.removeMarker(this.houseList);
          // }
          // houseList 교체
          this.pagination.pageNo = 1;
          this.houseList = res.data;
          this.housefilter();
          //this.setMarker(this.houseList);
        })
        .catch((error) => {
          alert(error);
          console.log(error);
        });
    },
    setMarker(houseList) {
      // 클러스터러 초기화
      if (this.kakaoMap.clusterer) {
        this.kakaoMap.clusterer.clear();
      }

      // 마커 클러스터러를 생성합니다
      this.kakaoMap.clusterer = new kakao.maps.MarkerClusterer({
        map: this.kakaoMap.mapObject, // 마커들을 클러스터로 관리하고 표시할 지도 객체
        averageCenter: true, // 클러스터에 포함된 마커들의 평균 위치를 클러스터 마커 위치로 설정
        minLevel: 6, // 클러스터 할 최소 지도 레벨
      });
      let markers = [];

      for (let houseinfo of houseList) {
        let markerImg = this.kakaoMap.normalMarkerImg;
        if (this.kakaoMap.selectedItem && houseinfo.aptCode == this.kakaoMap.selectedItem.aptCode) {
          markerImg = this.kakaoMap.selectedMarkerImg;
        }
        let markerPosition = new kakao.maps.LatLng(houseinfo.lat, houseinfo.lng);
        let marker = new kakao.maps.Marker({
          position: markerPosition,
          map: this.kakaoMap.mapObject,
          image: markerImg,
        });

        houseinfo.marker = marker;
        markers.push(marker);
        if (this.kakaoMap.selectedItem && houseinfo.aptCode == this.kakaoMap.selectedItem.aptCode) {
          this.kakaoMap.clickedMarker = houseinfo.marker;
        }
        // 마커에 마우스오버 이벤트가 발생하면 인포윈도우를 마커위에 표시합니다
        kakao.maps.event.addListener(marker, "mouseover", () => {
          this.mouseover(houseinfo);
        });
        // 마커에 마우스아웃 이벤트를 등록합니다
        kakao.maps.event.addListener(marker, "mouseout", () => {
          this.mouseout();
        });
        // 마커에 마우스클릭 이벤트를 등록합니다
        kakao.maps.event.addListener(marker, "click", () => {
          //this.moveMap(houseinfo);
          this.aptClick(houseinfo);
        });
      }

      this.kakaoMap.clusterer.addMarkers(markers);
    },
    moveMap(item) {
      // 지도 이동

      let coords = new kakao.maps.LatLng(item.lat, item.lng);
      //this.kakaoMap.mapObject.setLevel(4);
      this.kakaoMap.mapObject.panTo(coords);
    },
    mouseover(item) {
      if (this.kakaoMap.clickedOverlay) {
        this.kakaoMap.clickedOverlay.setMap(null);
      }
      if (this.kakaoMap.clickedMarker) {
        this.kakaoMap.clickedMarker.setImage(this.kakaoMap.normalMarkerImg);
      }
      if (this.kakaoMap.mouseOverOverlayList) {
        for (let item of this.kakaoMap.mouseOverOverlayList) {
          item.setMap(null);
        }
        this.kakaoMap.mouseOverOverlayList = [];
      }

      // 커스텀 오버레이에 표출될 내용으로 HTML 문자열이나 document element가 가능합니다
      let content = this.getCustomOverlay(item);

      // 커스텀 오버레이가 표시될 위치입니다
      let position = new kakao.maps.LatLng(item.lat, item.lng);

      // 커스텀 오버레이를 생성합니다
      this.kakaoMap.customOverlay = new kakao.maps.CustomOverlay({
        map: this.kakaoMap.mapObject,
        position: position,
        content: content,
        xAnchor: 0.5,
        yAnchor: 1.2,
      });

      this.kakaoMap.mouseOverOverlayList.push(this.kakaoMap.customOverlay);

      item.marker.setImage(this.kakaoMap.selectedMarkerImg);
      this.kakaoMap.selectedMarker = item.marker;
      this.kakaoMap.customOverlay.setMap(this.kakaoMap.mapObject);
    },
    mouseout() {
      this.kakaoMap.selectedMarker.setImage(this.kakaoMap.normalMarkerImg);
      if (this.kakaoMap.clickedMarker) {
        this.kakaoMap.clickedMarker.setImage(this.kakaoMap.selectedMarkerImg);
      }
      this.kakaoMap.customOverlay.setMap(null);
      if (this.kakaoMap.clickedOverlay) {
        this.kakaoMap.clickedOverlay.setMap(this.kakaoMap.mapObject);
      }
    },
    date(dealinfo) {
      let str = dealinfo.dealYear + ".";
      str += String(dealinfo.dealMonth).padStart(2, "0") + ".";
      str += String(dealinfo.dealDay).padStart(2, "0");

      return str;
    },
    area(num) {
      return Math.round(num * 0.3025);
    },
    amount(dealAmount) {
      return Math.round(parseInt(dealAmount.replace(",", "")) / 1000) / 10;
    },
    aptClick(item) {
      this.kakaoMap.selectedItem = item;
      if (this.kakaoMap.clickedMarker) {
        this.kakaoMap.clickedMarker.setImage(this.kakaoMap.normalMarkerImg);
      }
      if (this.kakaoMap.clickedOverlay) {
        this.kakaoMap.clickedOverlay.setMap(null);
      }

      ai.get("/house/" + item.aptCode + "?dealYear=" + 2021, {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          this.moveMap(item);
          let content = this.getCustomOverlay(item, true, res.data);

          // 커스텀 오버레이가 표시될 위치입니다
          let position = new kakao.maps.LatLng(item.lat, item.lng);

          // 커스텀 오버레이를 생성합니다
          this.kakaoMap.clickedOverlay = new kakao.maps.CustomOverlay({
            map: this.kakaoMap.mapObject,
            position: position,
            content: content,
            xAnchor: 0.5,
            yAnchor: 1.08,
          });

          this.kakaoMap.clickedMarker = item.marker;
          this.kakaoMap.clickedMarker.setImage(this.kakaoMap.selectedMarkerImg);

          let iconEl = document.getElementsByTagName("i");
          if (iconEl) {
            for (let i = 0; i < iconEl.length; i++) {
              iconEl[i].addEventListener("click", () => {
                this.closeOverlay();
              });
            }
          }

          let favouriteEl = document.getElementsByClassName("favorite-btn");
          if (favouriteEl) {
            for (let el of favouriteEl) {
              el.addEventListener("click", () => {
                // alert('찜했습니다.');
                // console.log(this.kakaoMap);
                // 관심목록 추가 기능 함수 호출
                this.addInterest(this.kakaoMap.selectedItem.aptCode, this.getUserId);
                this.modal(this.kakaoMap.selectedItem.aptName+ "을(를) 찜했습니다. 관심 APT 동네 모아보기로 모아보세요");
              });
            }
          }

          this.kakaoMap.clickedOverlay.setMap(this.kakaoMap.mapObject);
        })
        .catch((error) => {
          alert(error);
          console.log(error);
        });
    },
    // 관심목록 추가기능
    async addInterest(aptCode, Id) {
      let data = {
        houseInfoAptCode: String(aptCode),
        userId: Id,
      };

      // insert 하기 전,  기존에 같은 데이터가 있는지 체크
      // let isExist = false;
      // EventBus.$emit('search-interest');
      try {
        const res = await ai.post(
          this.$store.getters.getBaseURL + "/api/interest",
          JSON.stringify(data),
          {
            headers: {
              "jwt-auth-token": this.$store.getters.getAccessToken,
              "Content-Type": `application/json`,
            },
          }
        );
        console.log(res);
        if(res.data == -1){
          this.modal("이미 찜한 아파트입니다");
        }
      } catch (error) {
        alert("네트워크 에러 또는 유효하지 않은 토큰입니다.");
        console.log(error);
      }
    },
    closeOverlay() {
      if (this.kakaoMap.clickedOverlay) {
        this.kakaoMap.clickedOverlay.setMap(null);
        this.kakaoMap.clickedOverlay = null;
      }
      if (this.kakaoMap.clickedMarker) {
        this.kakaoMap.clickedMarker.setImage(this.kakaoMap.normalMarkerImg);
        this.kakaoMap.clickedMarker = null;
      }
      this.kakaoMap.selectedItem = null;
    },
    getCustomOverlay(item, click, dealList) {
      let content = `            <div id="custom-layout" class="shadow px-1 pt-2 pb-1">
              <!-- 아파트 이름 -->
              <div role="alert" class="alert h6 bg-secondary text-center py-1 mx-1 mb-1 alert-default"> ${item.aptName} </div>
              `;

      if (click) {
        //<i class="ni ni-favourite-28" style="font-size:8px"></i>
        content += `<i class="close-btn rounded-circle ni ni-fat-remove mr-2" style="font-size:24px; position: absolute; top:12px; right:8px;"></i>`;
        content += `<div class="favorite-btn rounded px-2"
                          style="font-size: 12px; position: absolute; top:15px; left: 15px;
                            ">

                      찜하기
                    </div>`;
      }
      content += `<!-- 아파트 상세 정보 -->
              <div id="aptinfo" class="mx-1">
                <div class="bg-white px-2 pt-1 pb-1 mb-1 rounded text-center">
                  <div class="row mx-1 py-1 border-bottom">
                    <div class="col-5 text-left">평균매매가</div>
                    <div class="border-left col-7 p-0">
                      <span class="mycolor">${Math.round(item.avgAmount / 1000) / 10}</span
                      >억
                    </div>
                  </div>
                  <div class="row mx-1 py-1 border-bottom">
                    <div class="col-5 text-left">전용면적</div>
                    <div class="border-left col-7 p-0">
                      <span class="mycolor">${Math.round(item.minArea * 0.3025 * 10) / 10}</span
                      >평 ~ <span class="mycolor">${
                        Math.round(item.maxArea * 0.3025 * 10) / 10
                      }</span
                      >평
                    </div>
                  </div>
                  <div class="row mx-1 py-1 border-bottom">
                    <div class="col-5 text-left">법정동</div>
                    <div class="border-left col-7 p-0">
                      <a href="#/towninfo?dongCode=${item.dongCode}"><span class="mycolor">${
        item.dong
      }</span></a>
                    </div>
                  </div>
                  <div class="row mx-1 py-1">
                    <div class="col-5 text-left">건축년도</div>
                    <div class="border-left col-7 p-0">
                      <span class="mycolor">${item.buildYear}</span
                      >년
                    </div>
                  </div>
                </div>`;

      if (click) {
        content += `<!-- 거래 정보 -->
        <div id="dealinfo" class="bg-white px-2 pt-1 pb-0 mb-1 rounded text-center">
          <div class="row housedeal mx-1 mb-0 border-bottom pb-1">
            <div class="col-6 align-self-center">최근 거래정보</div>
            <div class="col-6 align-self-center">${dealList.length} 건</div>
          </div>`;

        if (dealList) {
          for (item of dealList) {
            content += `
            <div class="row housedeal mx-1 py-1 border-bottom">
              <div class="col-5 text-center px-1">${this.date(item)}</div>
              <div class="col-2 text-right">${item.floor}층</div>
              <div class="col-2 text-right">${this.area(item.area)}평</div>
              <div class="col-2 text-right">${this.amount(item.dealAmount)}억</div>
            </div>`;
          }
        }

        content += `</div>
      </div>`;
      }

      content += `</div>`;

      return content;
    },
    moveTownInfo(item) {
      this.$router.push("/towninfo?dongCode=" + item.dongCode);
    },
    // addInterestDong -> 클릭시 userId + dongCode 를 post요청으로 user_interest_dong 정보에 추가
    async addInterestDong(item) {
      this.modal(item.dong + " 관심동 등록!")
      try {
        //console.log(this.getUserId + ", " + item.dongCode);
        let url =
          this.$store.getters.getBaseURL +
          "/api/interest/dong/" +
          this.getUserId +
          "/" +
          item.dongCode;

        await ai
          .post(url, {
            headers: {
              "jwt-auth-token": this.$store.getters.getAccessToken,
            },
          })
          .then((res) => {
            alert(item.dong + " 관심 등록 성공!");
            console.log(res);
          })
          .catch((err) => {
            console.log(err);
            if (err.response.status == 500) {
              alert("이미 관심 등록을 했습니다");
            }
          });
      } catch (err) {
        alert("네트워크 에러 or 로그인 정보가 유효하지 않습니다.");
        console.log(err);
      }
    },
  },
};
</script>

<style>
#aptinfo {
  font-size: 14px;
}

#filter {
  font-size: 14px;
}

#dealinfo {
  height: 160px;
  overflow-y: auto;
}

.housedeal > div {
  padding-left: 0%;
  padding-right: 0%;
}

i {
  font-size: 24px;
}

.mycolor {
  color: #5e72e4;
}

#custom-layout {
  width: 310px;
  border: 2px solid;
  z-index: 4;
  border-color: lightslategrey;
  background-color: gainsboro;
  border-radius: 13px;
}

.favorite-btn {
  background-color: #172b4d;
  border: 1px solid;
  border-color: #8898aa;
  color: gainsboro;
}
.favorite-btn:hover {
  background-color: lightcoral;
}

.close-btn {
  color: white;
  font-size: 20px;
}
.close-btn:hover {
  color: #db4455;
  font-size: 20px;
}
</style>

<style scoped>
.dong-btn:hover {
  background-color: #172b4d !important;
}

.mybg {
  background-color: #5e72e4;
}

#group {
  height: calc(100% - (310px));
  overflow: auto;
}

#map {
  width: 100%;
  height: 100%;
}

#house-list {
  max-height: 720px;
  border: 2px solid;
  border-color: lightslategrey;
  background-color: gainsboro;
  position: absolute;
  z-index: 5;
  top: 15px;
  left: 15px;
  width: 310px;
  height: calc(100% - (30px));
  border-radius: 13px;
}

#house-list > div {
  position: relative;
  height: 100%;
}

#map-content {
  position: relative;
  height: calc(100vh - (110px));
}

::v-deep .dropdown-menu {
  max-height: 330px;
  overflow-y: auto;
}
</style>
