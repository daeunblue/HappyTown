<template>
  <div>
    <div class="container">
      <card shadow class="card-profile" no-body>
        <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
          <div class="card-profile-actions py-4 mt-lg-0">
            <base-button type="info" size="sm" class="mr-4" @click="write">작성 완료</base-button>
            <base-button type="default" size="sm" class="float-right" @click="board"
              >취소</base-button
            >
          </div>
        </div>
        <div class="text-center mt-5">
          <h3><i class="ni ni-chat-round mr-2" style="font-size:20px"></i>글 작성</h3>
        </div>
        <div class="m-3">
          <div class="form-group mt-3">
            <div class="mb-2">제목 :</div>
            <input
              type="text"
              class="form-control mb-3"
              id="exampleFormControlInput1"
              placeholder="제목을 입력하세요..."
              v-model="title"
            />
            <div class="mb-2">내용 :</div>
            <textarea
              class="form-control"
              id="exampleFormControlTextarea1"
              rows="5"
              placeholder="내용을 입력하세요..."
              v-model="content"
            ></textarea>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseVueFrontBoardWrite",

  data() {
    return {
      title:"",
      content:""
    };
  },

  mounted() {},

  methods: {
    board() {
      this.$router.push("board");
    },
    write() {
      if(this.content && this.title){
        ai.post("/post",{
          content: this.content,
          title: this.title,
          viewCount: 0,
          regId: this.$store.getters.getUserName
        },{
          headers:{
            "jwt-auth-token": this.$store.getters.getAccessToken,
          },
        }).then((res)=>{
          console.log(res);
          this.$router.push("/board");
        }).catch((error)=>{
          alert("글 작성 에러\n"+error);
        })
      }
      else {
        alert("내용을 채워주세요");
      }

    },
  },
};
</script>

<style scoped></style>
