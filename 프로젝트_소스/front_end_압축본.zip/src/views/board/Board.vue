<template>
  <div>
    <div class="container">
      <card shadow class="card-profile" no-body>
        <div class="text-center mt-5">
          <h3><i class="ni ni-chat-round mr-2" style="font-size: 24px"></i>Q&A 게시판</h3>
          <div class="h6 font-weight-300"><i class="ni location_pin mr-2"></i>happy house</div>
          <!-- <div class="h6 mt-4">
            <i class="ni business_briefcase-24 mr-2"></i>Solution Manager - Creative Tim Officer
          </div> -->
          <div><i class="ni education_hat mr-2"></i>글 작성은 회원만 가능합니다.</div>
        </div>
        <div class="container mt-3">
          <b-table class="border-default border-bottom" hover :items="getPage" :fields="fields">
            <template #cell(title)="data">
              <router-link
                :to="{
                  path: '/boarddetail',
                  query: { no: data.item.no },
                }"
              >
                {{ data.item.title }}
              </router-link>
              <!--
          <b-button size="sm" @click="info(row.item, row.index, $event.target)" class="mr-1">
            Info modal
          </b-button>
          -->
            </template>
          </b-table>
          <div class="container" style="position:relative;">
            <div id="pagination" class="pl-1 pt-1">
              <base-pagination
                class="mt-2"
                align="center"
                :page-count="getTotalPagesCnt"
                v-model="pagination.pageNo"
              ></base-pagination>
            </div>
            <div v-if="$store.getters.getUserId" class="" style="position:absolute; top:10px; right:15px;">
              <base-button type="info" size="sm" class="mr-4" @click="boardWrite"
                >글쓰기</base-button
              >
            </div>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseVueFrontBoard",

  data() {
    return {
      pagination: {
        itemPerPage: 10,
        pageNo: 1,
      },
      items: [],

      fields: [
        {
          key: "no",
          label: "글번호",
        },
        {
          key: "title",
          label: "제목",
        },
        {
          key: "regId",
          label: "글쓴이",
        },
        {
          key: "viewCount",
          label: "조회수",
        },
      ],
    };
  },

  mounted() {
    this.$store.dispatch('getNoti');
    this.getPosts();
  },

  computed: {
    getPage() {
      return this.items.slice(
        this.pagination.itemPerPage * (this.pagination.pageNo - 1),
        this.pagination.itemPerPage * this.pagination.pageNo
      );
    },
    getTotalPagesCnt() {
      return parseInt((this.items.length - 1) / this.pagination.itemPerPage) + 1;
    },
  },

  methods: {
    boardWrite() {
      this.$router.push("boardwrite");
    },
    async getPosts() {
      try {
        const res = await ai.get("/post", {
          headers: {
            "jwt-auth-token": this.$store.getters.getAccessToken,
          },
        });
        this.items = res.data;
      } catch (error) {
        alert("네트워크 에러 or Token없음");
        console.log(error);
      }
    },
  },
};
</script>

<style scoped></style>
