<template>
  <div>
    <div class="container">
      <card shadow>
        <div class="ml-5 mt-5">
          <router-link to="/board">
            <h3><i class="ni ni-chat-round mr-2 mt-1" style="font-size: 24px"></i>Q&A 게시판</h3>
          </router-link>
          <div class="h6 font-weight-300"><i class="ni location_pin mr-2"></i>happy house</div>
        </div>

        <div class="container">
          <div class="form-group mt-3 p-3">
            <div class="alert alert-primary" role="alert">
              <input type="text" class="h4 border-0 form-inline w-100" ref="input" style="background-color: #CCE5FF;" v-model="post.title">
            </div>
            <p class="ml-3">
              조회수 : <span class="font-weight-bold">{{ post.viewCount }}</span>
            </p>
            <p class="ml-3">
              작성자 : <span class="font-weight-bold">{{ post.regId }}</span>
            </p>
            <textarea
              class="form-control"
              id="exampleFormControlTextarea1"
              rows="5"
              placeholder="내용을 입력하세요..."
              v-model="post.content"
            ></textarea>
            <div class="row justify-content-end">
              <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
                <div class="pt-2">
                  <base-button type="info" size="sm" class="mr-4" @click="modify">수정 완료</base-button>
                  <base-button type="default" size="sm" class="float-right" @click="back"
                    >취소</base-button
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseVueFrontBoardWrite",

  data() {
    return {
      post: {},
    };
  },

  computed: {
    commentCnt() {
      return this.comments.length;
    },
  },

  async mounted() {
    this.$refs.input.focus()
    const query = this.$route.query;
    const response_post = await ai.get("/post/" + query.no, {
      headers: {
        "jwt-auth-token": this.$store.getters.getAccessToken,
      },
    });
    this.post = response_post.data;
  },

  methods: {
    modify() {
      const no = this.$route.query.no;

      ai.put("/post",{
        no: no,
        title: this.post.title,
        content: this.post.content,
        viewCount: 0,
        regId: this.$store.getters.getUserName,
      },{
					headers: {
						"jwt-auth-token": this.$store.getters.getAccessToken,
					},
				}).then((res)=>{
        console.log(res);
        this.$router.push("/boarddetail?no="+no);
      }).catch((error)=>{
        console.log(error);
        alert("수정 실패");
      })

    },
    back(){
      this.$router.push("/boarddetail?no="+this.$route.query.no);
    }
  },
};
</script>

<style scoped></style>
