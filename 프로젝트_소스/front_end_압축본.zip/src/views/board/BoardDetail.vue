<template>
  <div>
    <div>
      <b-modal id="modal-1" title="HAPPY TOWN" ok-title="확인" ok-only>
        <p class="my-4">{{ modaltext }}</p>
      </b-modal>
    </div>
    <div class="container">
      <card shadow>
        <div class="ml-5 mt-5">
          <router-link to="/board">
            <h3><i class="ni ni-chat-round mr-2 mt-1" style="font-size: 24px"></i>Q&A 게시판</h3>
          </router-link>
          <div class="h6 font-weight-300"><i class="ni location_pin mr-2"></i>happy house</div>
        </div>

        <div class="container">
          <div class="form-group mt-3 p-3">
            <div class="alert alert-primary" role="alert">
              <h4 class="mb-0 ml-3 font-weight-600">{{ post.title }}</h4>
            </div>
            <p class="ml-3">
              조회수 : <span class="font-weight-bold">{{ post.viewCount }}</span>
            </p>
            <p class="ml-3">
              작성자 : <span class="font-weight-bold">{{ post.regId }}</span>
            </p>
            <div class="border rounded p-3" style="min-height: 100px">
              {{ post.content }}
            </div>
            <!-- 댓글 -->
            <div class="row py-0 px-2 mt-2">
              <div class="col-2 align-self-center">{{ commentCnt }}개의 댓글</div>
              <div class="col-10 justify-content-end">
                <div class="text-lg-right align-self-lg-end">
                  <div
                    v-if="
                      $store.getters.getUserName == post.regId ||
                      $store.getters.getUserId == 'admin'
                    "
                    class="pt-2"
                  >
                    <base-button type="info" size="sm" class="mr-4" @click="modify"
                      >수정</base-button
                    >
                    <base-button type="danger" size="sm" class="float-right" @click="del"
                      >삭제</base-button
                    >
                  </div>
                </div>
              </div>
            </div>
            <hr />
            <div v-for="(comment, index) in comments" :key="index">
              <div class="alert alert-secondary row mx-1" role="alert">
                <div class="col-2 border-right border-white">
                  {{ comment.id }}
                </div>
                <div class="col-auto">
                  {{ comment.content }}
                </div>
                <div style="position: absolute; top: 6px; right: 10px">
                  <base-button
                    v-if="
                      $store.getters.getUserName == comment.id ||
                      $store.getters.getUserId == 'admin'
                    "
                    type="danger"
                    size="sm"
                    class="float-right small"
                    @click="commentDelete(comment.no)"
                    >삭제</base-button
                  >
                </div>
              </div>
            </div>

            <div v-if="$store.getters.getUserId">
              <div class="row mx-1">
                <textarea
                  style="resize: none"
                  class="form-control"
                  id="exampleFormControlTextarea1"
                  rows="2"
                  placeholder="댓글 내용을 입력하세요..."
                  v-model="content"
                ></textarea>
              </div>
              <div class="row justify-content-end px-2">
                <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
                  <div class="mt-2">
                    <base-button type="primary" size="sm" class="" @click="sendComment"
                      >등록</base-button
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseVueFrontBoardWrite",

  data() {
    return {
      modaltext: '',
      content: "",
      post: {},
      comments: [
        {
          id: "작성자1",
          content: "댓글입니다 가나다라바사",
        },
        {
          id: "작성자2",
          content:
            "동해물과 백두산이 마르고 닳도록 하느님이 보우하사 우리나라만세 무궁화 삼천리 화려강산",
        },
      ],
    };
  },

  computed: {
    commentCnt() {
      return this.comments.length;
    },
  },

  mounted() {
    this.$store.dispatch("getNoti");
    const query = this.$route.query;
    ai.get("/post/" + query.no, {
      headers: {
        "jwt-auth-token": this.$store.getters.getAccessToken,
      },
    })
      .then((res) => {
        this.post = res.data;
      })
      .catch((error) => {
        alert("네트워크 에러 or token없음");
        console.log(error);
      });

    ai.get("/comment/" + query.no, {
      headers: {
        "jwt-auth-token": this.$store.getters.getAccessToken,
      },
    })
      .then((res) => {
        this.comments = res.data;
      })
      .catch((error) => {
        alert("네트워크 에러 or token없음");
        console.log(error);
      });
  },

  methods: {
    modal(text) {
      this.modaltext = text;
      this.$bvModal.show("modal-1");
    },
    commentDelete(no) {
      ai.delete("/comment/" + no, {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          if (res.data == 1) {
            // this.$router.push("/boarddetail?no="+query.no);
            for (let i = 0; this.comments.length; i++) {
              if (this.comments[i].no === no) {
                this.comments.splice(i, 1);
                break;
              }
            }
          } else {
            alert(res);
            console.log(res);
          }
        })
        .catch((error) => {
          alert("네트워크 에러 or 토큰 없음");
          console.log(error);
        });
    },
    sendComment() {
      if (this.content) {
        const query = this.$route.query;
        ai.post(
          "/comment/" + query.no,
          {
            id: this.$store.getters.getUserName,
            content: this.content,
          },
          {
            headers: {
              "jwt-auth-token": this.$store.getters.getAccessToken,
            },
          }
        )
          .then((res) => {
            if (res.data == 1) {
              // this.$router.push("/boarddetail?no="+query.no);
              this.$router.go();
            } else {
              alert(res);
              console.log(res);
            }
          })
          .catch((error) => {
            alert("네트워크 에러 or 토큰 없음");
            console.log(error);
          });
      } else {
        this.modal("댓글 내용을 작성해주세요");
      }
    },
    modify() {
      const query = this.$route.query;
      this.$router.push("/boardmodify?no=" + query.no);
    },
    del() {
      const query = this.$route.query;
      ai.delete("/post/" + query.no, {
        headers: {
          "jwt-auth-token": this.$store.getters.getAccessToken,
        },
      })
        .then((res) => {
          console.log(res);
          alert("삭제되었습니다.");
          this.$router.push("/board");
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>

<style scoped></style>
