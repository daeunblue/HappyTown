<template>
  <div>
    <div class="container">
      <card shadow>
        <div class="text-center mt-5">
          <h3><i class="ni ni-circle-08 mr-2" style="font-size: 24px"></i>내 정보</h3>
          <div class="h6 font-weight-300"><i class="ni location_pin mr-2"></i>happy house</div>
          <!-- <div class="h6 mt-4">
            <i class="ni business_briefcase-24 mr-2"></i>Solution Manager - Creative Tim Officer
          </div> -->
          <div><i class="ni education_hat mr-2"></i>회원 정보를 수정하세요</div>
        </div>

        <div class="container">
          <div class="form-group mt-3 p-3">
            <div class="row mb-3 pr-3">
              <div
                class="col-3 h5 font-weight-bold text-dark text-right pr-5 align-self-center m-0"
                role="alert"
              >
                아이디 :
              </div>
              <div class="col-9 input-group input-group-lg p-0">
                <input
                  type="text"
                  class="form-control p-4"
                  aria-label="Sizing example input"
                  aria-describedby="inputGroup-sizing-lg"
                  placeholder="아이디"
                  v-model="user.id"
                  disabled
                />
              </div>
            </div>
            <div class="row mb-3 pr-3">
              <div
                class="col-3 h5 font-weight-bold text-dark text-right pr-5 align-self-center m-0"
                role="alert"
              >
                비밀번호 :
              </div>
              <div class="col-9 input-group input-group-lg p-0">
                <input
                  type="password"
                  autocomplete="chrome-off"
                  class="form-control p-4"
                  aria-label="Sizing example input"
                  aria-describedby="inputGroup-sizing-lg"
                  placeholder="새 비밀번호(선택)"
                  v-model="user.password"
                  :disabled="kakao"
                />
              </div>
            </div>
            <div class="row mb-3 pr-3">
              <div
                class="col-3 h5 font-weight-bold text-dark text-right pr-5 align-self-center m-0"
                role="alert"
              >
                이름 :
              </div>
              <div class="col-9 input-group input-group-lg p-0">
                <input
                  type="text"
                  class="form-control p-4"
                  aria-label="Sizing example input"
                  aria-describedby="inputGroup-sizing-lg"
                  placeholder="이름"
                  v-model="user.name"
                  :disabled="kakao"
                />
              </div>
            </div>
            <div class="row mb-3 pr-3">
              <div
                class="col-3 h5 font-weight-bold text-dark text-right pr-5 align-self-center m-0"
                role="alert"
              >
                주소 :
              </div>
              <div class="col-9 input-group input-group-lg p-0">
                <input
                  type="text"
                  class="form-control p-4"
                  aria-label="Sizing example input"
                  aria-describedby="inputGroup-sizing-lg"
                  placeholder="주소"
                  v-model="user.address"
                  :disabled="kakao"
                />
              </div>
            </div>

            <div class="row justify-content-end">
              <div class="col-lg-4 order-lg-3 text-lg-right align-self-lg-end">
                <div class="pt-2">
                  <base-button v-if="!this.kakao" type="info" size="sm" class="mr-4" @click="update">수정</base-button>
                  <base-button v-if="!this.kakao" type="danger" size="sm" class="float-right" @click="del"
                    >회원 탈퇴</base-button
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end container -->
      </card>
    </div>
  </div>
</template>

<script>
import ai from "@/js/axios.js";

export default {
  name: "HappyhouseFinalSeoul11FrontKimdaeunKimdaeheeUserInfo",

  data() {
    return {
      kakao:false,
      user: {
        id: "",
        password: "",
        address: "",
        name: "",
      },
    };
  },

  mounted() {
    this.$store.dispatch("getNoti");
    this.user.id = this.$store.state.user.id;
    this.user.address = this.$store.state.user.address;
    this.user.name = this.$store.state.user.name;
    if(this.user.name.search("kakao") > 0){
      this.kakao = true;
      this.user.address = "카카오 유저는 수정할 수 없음";
      this.user.address = "카카오 유저는 수정할 수 없음";
    }
    
  },

  methods: {
    async update() {
      try {
        const res = await ai.put("/user", {
          headers: {
            "jwt-auth-token": this.$store.getters.getAccessToken,
          },
          id: this.user.id,
          password: this.user.password,
          name: this.user.name,
          address: this.user.address,
        });
        console.log("res", res);
        if (res.data.success) {
          alert("수정 완료되었습니다.");
          this.$store.commit("setAccessToken", {
            id: this.user.id,
            name: this.user.name,
            address: this.user.address,
          });
          this.$router.push("/");
        }
      } catch (error) {
        alert("네트워크 에러");
        console.log(error);
      }
    },
    async del() {
      try {
        const res = await ai.delete("/user/" + this.user.id, {
      headers: {
        "jwt-auth-token": this.$store.getters.getAccessToken,
      },
    });
        console.log("res", res);
        if (res.data.success) {
          alert("삭제되었습니다.");
          this.$store.commit("logout");
          this.$router.push("/");
        }
      } catch (error) {
        alert(error);
        console.log(error);
      }
    },
  },
};
</script>

<style scoped></style>
