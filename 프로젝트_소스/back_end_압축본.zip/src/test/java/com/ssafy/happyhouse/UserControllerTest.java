package com.ssafy.happyhouse;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssafy.happyhouse.util.JwtUtil;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
@AutoConfigureMockMvc
public class UserControllerTest {
	
	@Autowired
	MockMvc mock;
	
	@Autowired
	JwtUtil jUtil;
	
	@Test
	@DisplayName("정보 전달-> 로그인 -> 토큰 유효확인")
	public void testLogin() throws Exception{
		Map<String,String> map = new HashMap<>();
		map.put("id", "test123");
		map.put("password", "test1234");
		
		String content = new ObjectMapper().writeValueAsString(map);
		
		MockHttpServletRequestBuilder reqBuilder = post("/user/login").contentType("application/json").content(content);
		ResultActions action = mock.perform(reqBuilder);
		
		action.andExpect(status().is(202));
		
	}
}
