package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.dto.StoreCnt;
import com.ssafy.happyhouse.model.repo.StoreCntRepo;
import com.ssafy.happyhouse.model.service.HouseInfoService;
import com.ssafy.happyhouse.model.service.StoreCntService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class StoreCntTest {

	@Autowired
	StoreCntRepo repo;
	
	@Autowired
	StoreCntService sService;
	
	@Autowired
	HouseInfoService hService;
	
	@Test
	public void test() throws SQLException {
		
		assertNotNull(repo);
		
		Map<String, String> condition = new HashMap<>();
		condition.put("kind", "생활서비스");
		condition.put("dongCode", "1120000000");
		List<StoreCnt> list = repo.select(condition);
	}
	
	@Test
	public void test2() throws SQLException {
		
		assertNotNull(sService);
		List<StoreCnt> list = sService.select("생활서비스", "1120000000");
		System.out.println(list);
		list.forEach((item)->{System.out.println(item);});
	}
	
	
	@Test
	public void selectInterestTest() {
		List<StoreCnt> result = new ArrayList<StoreCnt>();
		List<DongInfo> dongList = hService.selectByUserId("test123");
		
		for (DongInfo info : dongList) {
			StoreCnt cnt = sService.selectById("학문", info.getDongCode());
			log.debug(cnt.toString());
			cnt.setDongName(info.getDong());
			result.add(cnt);
		}
		log.debug("최종 결과 : {}", result);
		assertNotNull(result);
	}

	
}
