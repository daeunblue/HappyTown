package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.User;
import com.ssafy.happyhouse.model.service.UserService;
import com.ssafy.happyhouse.util.JwtUtil;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class TokenTest {
	@Autowired
	JwtUtil util;
	
	@Autowired
	UserService uService;
	
	@Test
	public void tokenCreateTest() throws Exception {
		Map<String, String> map = new HashMap<>();
		User user = uService.selectUser("1234");
		log.debug("user: {}", user.toString());
		map.put("id", user.getId());
		map.put("password", user.getPassword());
		
		String token = util.createAuthToken(map);
		assertNotNull(token);
		log.debug(token);
	}
}
