package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.AptSale;
import com.ssafy.happyhouse.model.repo.NotificationRepo;
import com.ssafy.happyhouse.model.service.AptSaleService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class AptSaleTest {
	
	@Autowired
	AptSaleService service;
	
	@Autowired
	NotificationRepo repo;
	
	@Test
	public void beanTest() {
		assertNotNull(service);
	}
	
	@Test
	public void selectTest() throws SQLException {
		List<AptSale> list = service.selectAptSaleAll();
		assertNotNull(list);
	}
	
	@Test
	public void singleSelectTest() throws SQLException {
		assertNotNull(service.selectAptSale(1));
		assertNull(service.selectAptSale(2));
		
	}

	@Test
	public void te2() throws SQLException {
		//repo.insert(AptSale.builder().dongName("123").title("제목").no(123).build());
		//System.out.println(repo.select("admin"));
		repo.delete(18);
		
		
	}
	
	

}
