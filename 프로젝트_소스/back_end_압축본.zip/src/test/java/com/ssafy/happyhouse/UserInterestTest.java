package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ssafy.happyhouse.controller.UserInterestRestController;
import com.ssafy.happyhouse.dto.User;
import com.ssafy.happyhouse.dto.UserInterest;
import com.ssafy.happyhouse.model.repo.UserInterestHouseRepo;
import com.ssafy.happyhouse.model.service.UserInterestHouseService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
@Transactional
public class UserInterestTest {
	
	@Autowired
	UserInterestHouseRepo repo;
	
	@Autowired
	UserInterestHouseService service;
	
	@Autowired
	UserInterestRestController controller;
	
	@Test
	public void selectTest() {
		assertNotNull(repo.selectInfo("test123"));
	}
	
	@Test
	@Transactional
	public void insertTest() {
		assertEquals(1, repo.insert(new UserInterest().builder().userId("test123").houseInfoAptCode("11110000000133").build()));
	}
	
//	@Test
//	@Transactional
//	public void updateTest() {
//		assertEquals(1, repo.update(new UserInterest().builder().userId("test123").houseInfoAptCode("11170000000044").build()));
//	}
	
	
	
	
	@Test
	@Transactional
	public void insertCheckTest() throws SQLException {
		UserInterest interest = new UserInterest().builder().userId("test123").houseInfoAptCode("11110000000008").build();
		assertEquals(1, controller.insertInterest(interest));
	}
}
