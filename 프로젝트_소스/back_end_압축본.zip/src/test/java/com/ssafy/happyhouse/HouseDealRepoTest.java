package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.HouseDeal;
import com.ssafy.happyhouse.model.repo.HouseDealRepo;
import com.ssafy.happyhouse.model.service.HouseDealService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class HouseDealRepoTest {
	
	@Autowired
	HouseDealService repo;
	
	@Test
	public void beanTest() {
		assertNotNull(repo);
	}
	
	@Test
	public void selectTest() {
		Map<String, String> map = new HashMap<>();
		List<HouseDeal> list = repo.select("11110000000001", "2021");
		assertNotNull(list);
		log.debug("list : {}", list);
		
	}

}
