package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.GugunInfo;
import com.ssafy.happyhouse.model.service.GugunInfoService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class GugunInfoTest {

	@Autowired
	GugunInfoService gService;
	
	@Test
	public void selectTest() throws SQLException {
		
		List<GugunInfo> result = gService.searchByName("1111000000");
		assertNotNull(result);
		log.debug("select : {}", result);
	}
	
	@Test
	public void getAvgTest() throws SQLException{
		double result = gService.getAvg();
		assertEquals(101, result);
		log.debug("select : {}", result);
	}
	
	

}
