package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.dto.GugunInfo;
import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.LocationInfo;
import com.ssafy.happyhouse.model.repo.HouseInfoRepo;
import com.ssafy.happyhouse.model.service.GugunInfoService;
import com.ssafy.happyhouse.model.service.HouseInfoService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class HouseInfoRepoTest {

	@Autowired
	HouseInfoRepo repo;
	
	@Autowired
	HouseInfoService hService;
	
	@Autowired
	GugunInfoService gService;
	
	@Test
	public void beanCreationTest() {
		assertNotNull(repo);
	}
	
	@Test
	public void selectTest() {
		LocationInfo li = LocationInfo.builder().minLat(37.59055408479135).maxLat(37.62210173084318)
				.minLng(126.94408875811227).maxLng(126.99245592983948).build();
		List<HouseInfo> list = repo.selectByLocation(li);
		assertNotNull(list);
		log.debug("결과 : {}", list);
	}
	
	@Test
	public void selectByIdTest() throws SQLException {
		List<DongInfo> dongList = hService.selectByUserId("test123");
		assertNotNull(dongList);
		List<GugunInfo> result = new ArrayList<GugunInfo>();
		
		for(DongInfo info : dongList) {
			GugunInfo gugunInfo = gService.searchByName(info.getGugunCode()).get(0);
			gugunInfo.setDongName(info.getDong());
			log.debug("정보 : {}", gugunInfo.toString());
			
//			result.add(gugunInfo); 
//			log.debug("동 이름:{}", gugunInfo.getDongName());
		}
		
//		log.debug("dongList: {}", dongList);
//		List<Crime> cList = new ArrayList<Crime>();
//		for(DongInfo info : dongList) {
//			Crime result = null;
//			result = cService.searchByName(info.getGugunCode());
//			cList.add(result);
//			log.debug(cService.searchByName("결과"+info.getGugunCode()).getCrimeCnt()+", "+ info.getDong());
		}
//		log.debug("결과: {}", cList);
//		assertNotNull(cList);

}

