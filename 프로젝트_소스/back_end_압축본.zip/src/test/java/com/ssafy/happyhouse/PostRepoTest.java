package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.dto.Post;
import com.ssafy.happyhouse.model.repo.PostRepo;

import lombok.Builder;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Transactional
@Slf4j
public class PostRepoTest {

	@Autowired
	PostRepo repo;
	
	@Test
	public void repoTest() {
		assertNotNull(repo);
	}
	
	@Test
	public void insertTest() throws SQLException {
		Post post = Post.builder().regId("ssafy").title("test3").content("test중입니다~@@").viewCount(0).build();
		assertEquals(1, repo.insert(post));
	}
	
	@Test
	public void selectTest() throws SQLException{
		assertNotNull(repo.select(1));
		assertEquals("ssafy", repo.select(5).getRegId());
	}
	
	@Test
	public void updateTest() throws SQLException{
		Post post = Post.builder().regId("ssafy").title("test3UPDATE").content("update test중입니다~@@").viewCount(0).no(5).build();
		assertEquals(1, repo.update(post));
	}
	
	@Test
	public void deleteTest() throws SQLException{
		int deleteNo = 6;
		assertEquals(1, repo.delete(deleteNo));
	}

	@Test
	public void searchByIdTest() throws SQLException{
		String regId = "ssafy";
		assertEquals(3, repo.searchById(regId).size());
	}
	
	@Test
	public void selectAllTest() throws SQLException{
		assertNotNull(repo.selectAll());
	}
}
