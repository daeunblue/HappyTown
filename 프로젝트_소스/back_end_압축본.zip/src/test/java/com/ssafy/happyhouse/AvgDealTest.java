package com.ssafy.happyhouse;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.happyhouse.dto.AvgDealAmount;
import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.model.service.AvgDealAmountService;
import com.ssafy.happyhouse.model.service.HouseInfoService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class AvgDealTest {
	
	@Autowired
	AvgDealAmountService aService;
	
	@Autowired
	HouseInfoService hService;
	
	@Test
	public void selectTest() {
		double result = aService.getGuAvg("1168010100");
		assertEquals(6264, result);
	}
	
	@Test
	public void selectListTest() {
		List<AvgDealAmount> list = aService.getGuInfo("1168010100");
		assertEquals(13, list.size());
	}
	
	@Test
	public void selectInterestTest() {
		List<AvgDealAmount> result = new ArrayList<AvgDealAmount>();
		
		List<DongInfo> dongList = hService.selectByUserId("test123");
		log.debug("동 리스트 : {}",dongList);
		for(DongInfo info : dongList) {
			Double deal = aService.getDongAvg(info.getDongCode());
			log.debug(deal.toString());
			AvgDealAmount amount = new AvgDealAmount().builder().dongCode(info.getDongCode())
					.avgDealAmountPerArea(deal).dongName(info.getDong()).build();
			result.add(amount);
		}
		log.debug("최종 결과 : {}",result);
	}
}
