package com.ssafy.happyhouse.model.repo;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.UserInterest;

@Repository
public interface UserInterestHouseRepo {
	int insert(UserInterest interest);
//	int update(UserInterest interest); // update가 필요한 이유가 X -> 사용자가 관심목록창에서 굳이 관심목록을 수정할 일이 없다. 삭제하고 새 관심목록을 추가하면 되기 때문
	int delete(UserInterest uInterest);
	List<UserInterest> select(String id);
	List<HouseInfo> selectInfo(String id);
	String selectId(String no);
}
