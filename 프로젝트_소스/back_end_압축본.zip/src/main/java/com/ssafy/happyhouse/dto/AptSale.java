package com.ssafy.happyhouse.dto;


import java.sql.Blob;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AptSale {
	private int no;
	private String aptName;
	private String dongName;
	private String regId;
	private String title;
	private String content;
//	// DB에 저장할때 사용하는 img
//	private byte[] imgBytes;
	// DB에서 꺼낼때 사용하는 img
	private byte[] img;
	// front에게 전달하는 img 주소 경로
	private String imgSrcUrl;
	// 0이면 판매중 1이면 판매완료
	private int soldout;

}
