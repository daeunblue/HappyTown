package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.dto.HouseDeal;

public interface HouseDealService {
	List<HouseDeal> select(String aptCode, String dealYear);
}
