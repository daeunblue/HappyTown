package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.dto.StoreCnt;

public interface StoreCntService {
	
	List<StoreCnt> select(String kind, String dongCode); 
	
	StoreCnt selectById(String kind, String dongCode); 
	
}
