package com.ssafy.happyhouse.model.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.dto.GugunInfo;

@Repository
public interface GugunInfoRepo {
	List<GugunInfo> select(String dongCode);
	
	Double getAvg();
	
}
