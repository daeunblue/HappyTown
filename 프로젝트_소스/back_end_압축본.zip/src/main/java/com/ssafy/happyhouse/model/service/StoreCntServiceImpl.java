package com.ssafy.happyhouse.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.StoreCnt;
import com.ssafy.happyhouse.model.repo.StoreCntRepo;

@Service
public class StoreCntServiceImpl implements StoreCntService {
	
	@Autowired
	StoreCntRepo repo;

	@Override
	public List<StoreCnt> select(String kind, String dongCode) {
		
		Map<String, String> condition = new HashMap<>();
		condition.put("kind", kind);
		condition.put("dongCode", dongCode);
		List<StoreCnt> list = repo.select(condition); 
		return list;
	}

	@Override
	public StoreCnt selectById(String kind, String dongCode) {
		return repo.selectById(kind, dongCode);
	}

}
