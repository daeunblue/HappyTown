package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ssafy.happyhouse.dto.AptSale;

public interface AptSaleService {
	int registAptSale(AptSale aptSale, MultipartFile imgfile) throws SQLException;
	
	AptSale selectAptSale(int no) throws SQLException;
	
	List<AptSale> selectAptSaleAll() throws SQLException;
	
	int updateAptSale(AptSale aptSale) throws SQLException;
	
	int deleteAptSale(int no) throws SQLException;

}
