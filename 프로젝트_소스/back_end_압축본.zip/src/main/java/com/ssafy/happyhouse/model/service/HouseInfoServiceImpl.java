package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.LocationInfo;
import com.ssafy.happyhouse.model.repo.HouseInfoRepo;

@Service
public class HouseInfoServiceImpl implements HouseInfoService{
	
	@Autowired
	HouseInfoRepo repo;
	
	@Override
	public List<HouseInfo> selectByLocation(LocationInfo locationInfo) {
		return repo.selectByLocation(locationInfo);
	}

	@Override
	public List<DongInfo> selectByUserId(String userId) {
		return repo.selectByUserId(userId);
	}	

}
