package com.ssafy.happyhouse.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ssafy.happyhouse.interceptor.SessionInterceptor;

@Configuration
public class MvcConfig implements WebMvcConfigurer{
	
	@Autowired
	SessionInterceptor si;
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		//로그인해야 들어갈 수 있는 경로 설정
		registry.addInterceptor(si)
		.addPathPatterns("/user/info")
		.excludePathPatterns("/**/*.js", "/**/*.css", "/**/*.png", "/**/*.jpg");

	}
	

}
