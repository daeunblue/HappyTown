package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.Post;
import com.ssafy.happyhouse.model.service.PostService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/post")
@CrossOrigin("*")
public class PostRestController {
	
	@Autowired
	PostService pService;
	
	@PostMapping
	@ApiOperation(value="전달받은 게시글 저장", response = Integer.class)
	public ResponseEntity<Integer> insert(@RequestBody Post post) throws SQLException {
		int result = pService.registPost(post);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);		
	}
	
	@GetMapping
	@ApiOperation(value="모든 게시글 정보 반환", response = Post.class)
	public ResponseEntity<List<Post>> selectAll()throws SQLException{
		List<Post> result = pService.selectPostAll();
		return new ResponseEntity<List<Post>>(result, HttpStatus.OK);
	}
	
	@GetMapping("/{no}")
	@ApiOperation(value="{no}애 해당되는 게시글 정보 반환", response = Post.class)
	public ResponseEntity<Post> select(@PathVariable int no) throws SQLException{
		Post result = pService.selectPost(no);
		return new ResponseEntity<Post>(result, HttpStatus.OK);
	}
	
	@PutMapping
	public ResponseEntity<Integer> update(@RequestBody Post post) throws SQLException{
		int result = pService.updatePost(post);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	
	@DeleteMapping("/{no}")
	public ResponseEntity<Integer> delete(@PathVariable int no) throws SQLException{
		int result = pService.deletePost(no);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	

}
