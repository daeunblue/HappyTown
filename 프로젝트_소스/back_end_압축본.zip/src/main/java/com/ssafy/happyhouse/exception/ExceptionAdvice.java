package com.ssafy.happyhouse.exception;

import java.sql.SQLException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionAdvice {
	
	@ExceptionHandler(SQLException.class)
	//@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<String> ExceptionAdvice(SQLException e) {
		return new ResponseEntity<String>("sql오류", HttpStatus.INTERNAL_SERVER_ERROR); // 500 에러 반환하기
	}
}
