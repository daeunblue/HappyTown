package com.ssafy.happyhouse.model.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.happyhouse.dto.AvgDealAmount;

@Repository
public interface AvgDealAmountRepo {
	Double selectByDong(String dongcode);
	List<AvgDealAmount> selectByGu(String dongcode);	
	Double selectDongAvg(String dongcode);
}
