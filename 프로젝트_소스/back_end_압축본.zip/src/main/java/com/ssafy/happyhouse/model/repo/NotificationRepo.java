package com.ssafy.happyhouse.model.repo;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.dto.AptSale;
import com.ssafy.happyhouse.dto.Notification;

public interface NotificationRepo {
	
	int insert(AptSale aptSale);
	
	int welcome(String id);
	
	int msg(Map map);
	
	List<Notification> select(String id);
	
	int delete(int no);
}
