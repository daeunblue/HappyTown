package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.GugunInfo;
import com.ssafy.happyhouse.model.repo.GugunInfoRepo;

@Service
public class GugunInfoServiceImpl implements GugunInfoService{

	@Autowired
	GugunInfoRepo repo;
	
	@Override
	public List<GugunInfo> searchByName(String dongCode) throws SQLException {
		return repo.select(dongCode);
	}

	@Override
	public Double getAvg() throws SQLException {
		return repo.getAvg();
	}
	
}
