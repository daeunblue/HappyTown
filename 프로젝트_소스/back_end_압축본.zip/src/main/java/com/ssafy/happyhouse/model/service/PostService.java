package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.dto.Post;

public interface PostService {
	int registPost(Post post) throws SQLException;
	
	Post selectPost(int no) throws SQLException;
	
	List<Post> selectPostAll() throws SQLException;
	
	int updatePost(Post post) throws SQLException;
	
	int deletePost(int no) throws SQLException;
	
	boolean matchUser(String regId,String id) throws SQLException;
}
