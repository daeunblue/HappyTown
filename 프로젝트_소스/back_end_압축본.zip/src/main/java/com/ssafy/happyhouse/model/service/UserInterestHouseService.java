package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.UserInterest;

public interface UserInterestHouseService {
	List<HouseInfo> selectUserHouse(String userId) throws SQLException;
	int insertInterest(UserInterest uInterest) throws SQLException;
	int deleteInterest(UserInterest uInterest) throws SQLException;
	String selectId(String no)throws SQLException;
}
