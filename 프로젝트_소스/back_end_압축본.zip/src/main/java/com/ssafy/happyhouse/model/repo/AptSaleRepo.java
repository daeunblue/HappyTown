package com.ssafy.happyhouse.model.repo;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.dto.AptSale;

public interface AptSaleRepo {
	
	int insertAptSale(AptSale aptSale) throws SQLException;
	
	Map<String, Object> selectAptSale(int no) throws SQLException;
	
	List<Map<String, Object>> selectAptSaleAll() throws SQLException;
	
	int soldout(int no);
	
	int updateAptSale(AptSale aptSale) throws SQLException;
	
	int delete(int no) throws SQLException;
}
