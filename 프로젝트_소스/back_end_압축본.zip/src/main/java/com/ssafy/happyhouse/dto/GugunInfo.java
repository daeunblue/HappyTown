package com.ssafy.happyhouse.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GugunInfo {
	private String gugunName;
	private String population;
	private String crimeCnt;
	private Double crimeCntPerPopulation10000;
	private int polluterCnt;
	private int parkCnt;
	private int parkArea;
	
	private String dongName;
}
