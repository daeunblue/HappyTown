package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.UserInterest;
import com.ssafy.happyhouse.model.repo.UserInterestHouseRepo;

@Service
public class UserInterestHouseServiceImpl implements UserInterestHouseService {

	@Autowired
	UserInterestHouseRepo repo;

	@Override
	public List<HouseInfo> selectUserHouse(String userId) throws SQLException {
		return repo.selectInfo(userId);
	}

	@Override
	public int insertInterest(UserInterest uInterest) throws SQLException {
		return repo.insert(uInterest);
	}

	@Override
	public int deleteInterest(UserInterest uInterest) throws SQLException {
		return repo.delete(uInterest);
	}

	@Override
	public String selectId(String no) throws SQLException {
		return repo.selectId(no);
	}
	
}
