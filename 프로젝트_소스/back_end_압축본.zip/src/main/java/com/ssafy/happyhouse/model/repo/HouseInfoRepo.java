package com.ssafy.happyhouse.model.repo;

import java.util.List;

import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.LocationInfo;

public interface HouseInfoRepo {

	List<HouseInfo> selectByLocation(LocationInfo locationInfo);
	List<DongInfo> selectByUserId(String userId);
}
