package com.ssafy.happyhouse.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HouseInfo {
	/* 아파트 코드 */
	private String aptCode;
	/**아파트 이름 */
	private String aptName;
	/**법정 동 */
	private String dong;
	private String dongCode;
	/**전용면적 */
	private double minArea;
	private double maxArea;
//	/**지번*/
//	private String jibun;
	/*건축년도*/
	private String buildYear;
	/* 위도 */
	private String lat;
	/* 경도 */
	private String lng;
	// 평균 거래가 (2018~2022)
	private String avgAmount;
}
