package com.ssafy.happyhouse.dto;

public class Polluter {

}
