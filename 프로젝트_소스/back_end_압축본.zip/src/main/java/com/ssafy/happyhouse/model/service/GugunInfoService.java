package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.dto.GugunInfo;

public interface GugunInfoService {

	List<GugunInfo> searchByName(String gugunCode) throws SQLException;
	
	Double getAvg() throws SQLException;
}
