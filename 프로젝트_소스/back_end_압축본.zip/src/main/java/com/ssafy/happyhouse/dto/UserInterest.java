package com.ssafy.happyhouse.dto;

import java.math.BigInteger;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserInterest {
	String userId;
	// db에선 BigInt 형이라서 처리하려고했는데 범위를 벗어남 -> String으로 대체했는데 이래도 되는건지..? 일단 놔둬보겠음,,,
	String houseInfoAptCode;
	int no;
}
