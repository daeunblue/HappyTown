package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.AvgDealAmount;
import com.ssafy.happyhouse.model.repo.AvgDealAmountRepo;

@Service
public class AvgDealAmountServiceImpl implements AvgDealAmountService{

	@Autowired
	AvgDealAmountRepo repo;
	
	@Override
	public Double getGuAvg(String dongCode) {
		return repo.selectByDong(dongCode);
	}

	@Override
	public List<AvgDealAmount> getGuInfo(String dongCode) {
		return repo.selectByGu(dongCode);
	}

	@Override
	public Double getDongAvg(String dongCode) {
		return repo.selectDongAvg(dongCode);
	}


}
