package com.ssafy.happyhouse.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StoreCnt {
	String gugunName;
	String dongName;
	String kind;
	int kindCnt;
	String dongcode;
}
