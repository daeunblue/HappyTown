package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.User;
import com.ssafy.happyhouse.model.service.UserService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/user")
@CrossOrigin("*")
@Slf4j
public class UserRestController {
	
	@Autowired
	UserService service;
	
	@GetMapping("/{id}")
	@ApiOperation(value = "회원 조회")
	public ResponseEntity<Map> selectUser(@PathVariable String id){
		Map<String, Object> map = new HashMap<>();
		
		try {
			map.put("user", service.selectUser(id));
			map.put("success", true);
		} catch (Exception e) {
			map.put("user", null);
			map.put("success", false);
			map.put("msg", "회원 조회 실패");
		}
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	@PutMapping
	@ApiOperation(value = "회원 정보 수정")
	public ResponseEntity<Map> updateUser(@RequestBody User user){
		Map<String, Object> map = new HashMap<>();
		try {
			service.updateUser(user);
			map.put("success", true);
		} catch (Exception e) {
			map.put("success", false);
			map.put("error", e.getMessage());
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	@ApiOperation(value = "회원 정보 삭제")
	public ResponseEntity<Map> deleteUser(@PathVariable String id){
		Map<String, Object> map = new HashMap<>();
		try {
			service.deleteUser(id);
			map.put("success", true);
		} catch (Exception e) {
			map.put("success", false);
			map.put("error", e.getMessage());
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	@PutMapping("/password")
	@ApiOperation(value = "비밀번호 변경")
	public ResponseEntity<Map> deleteUser(@RequestBody User user){
		Map<String, Object> map = new HashMap<>();
		try {
			service.updatePassword(user);
			map.put("success", true);
		} catch (Exception e) {
			map.put("success", false);
			map.put("error", e.getMessage());
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	@GetMapping("/match")
	@ApiOperation(value = "유저 확인(id, 이름)")
	public ResponseEntity<Map> matchUser(@RequestParam String id, @RequestParam String name, HttpSession session){
		Map<String, Object> map = new HashMap<>();
		map.put("success", false);
		try {
			if(service.matchUser(id, name)) {
				session.setAttribute("id", id);
				map.put("success", true);				
			}
		} catch (Exception e) {
			map.put("msg", e.getMessage());
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	
	
	
}
