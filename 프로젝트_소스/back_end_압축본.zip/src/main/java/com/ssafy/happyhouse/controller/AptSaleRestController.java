package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.happyhouse.dto.AptSale;
import com.ssafy.happyhouse.model.service.AptSaleService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/aptsale")
@CrossOrigin("*")
@Slf4j
public class AptSaleRestController {
	
	@Autowired
	AptSaleService aService;
	
	@PostMapping
	@ApiOperation(value="전달받은 APT 매물", response = Integer.class)
	public ResponseEntity<Integer> insert(@RequestPart MultipartFile imgfile, @RequestParam Map<String, String> map) throws SQLException {
		
		AptSale aptSale = AptSale.builder()
				.title(map.get("title"))
				.content(map.get("content"))
				.aptName(map.get("aptName"))
				.dongName(map.get("dongName"))
				.regId(map.get("regId"))
				.build();
		
		int result = aService.registAptSale(aptSale, imgfile);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);		
	}
	
	@GetMapping
	@ApiOperation(value="모든 게시글 정보 반환", response = AptSale.class)
	public ResponseEntity<List<AptSale>> selectAll()throws SQLException{
		List<AptSale> result = aService.selectAptSaleAll();
		return new ResponseEntity<List<AptSale>>(result, HttpStatus.OK);
	}
	
	@GetMapping("/{no}")
	@ApiOperation(value="{no}애 해당되는 게시글 정보 반환", response = AptSale.class)
	public ResponseEntity<AptSale> select(@PathVariable int no) throws SQLException{
		AptSale result = aService.selectAptSale(no);
		return new ResponseEntity<AptSale>(result, HttpStatus.OK);
	}
	
	@PutMapping
	@ApiOperation(value="title, content, soldout만 update합니다.", response = AptSale.class)
	public ResponseEntity<Integer> update(@RequestBody AptSale aptSale) throws SQLException{
		int result = aService.updateAptSale(aptSale);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	
	@DeleteMapping("/{no}")
	@ApiOperation(value="{no}에 해당하는 아파트 매물 정보 삭제", response = AptSale.class)
	public ResponseEntity<Integer> delete(@PathVariable int no) throws SQLException{
		int result = aService.deleteAptSale(no);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	

}
