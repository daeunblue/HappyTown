package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.HouseDeal;
import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.LocationInfo;
import com.ssafy.happyhouse.model.service.HouseDealService;
import com.ssafy.happyhouse.model.service.HouseInfoService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/house")
@CrossOrigin("*")
@Slf4j
public class HouseRestController {
	
	@Autowired
	HouseInfoService HIService;
	@Autowired
	HouseDealService HDService;
	
	@GetMapping
	@ApiOperation(value="위치 정보를 받아 houseinfo 반환", response = HouseInfo.class)
	public ResponseEntity<List<HouseInfo>> getHouseInfo(@RequestParam Map<String, String> paramMap) throws SQLException {
		double minLat = Double.parseDouble(paramMap.get("minLat"));
		double maxLat = Double.parseDouble(paramMap.get("maxLat"));
		double minLng = Double.parseDouble(paramMap.get("minLng"));
		double maxLng = Double.parseDouble(paramMap.get("maxLng"));
		
		LocationInfo locInfo = new LocationInfo(minLat, maxLat, minLng, maxLng);
		
		log.debug("REST API, houseInfo : locInfo = {}", locInfo);
		
		List<HouseInfo> list = HIService.selectByLocation(locInfo);
		return new ResponseEntity<List<HouseInfo>>(list, HttpStatus.OK);
	}
	
	@GetMapping("/{aptCode}")
	@ApiOperation(value="aptCode를 받아 housedeal 반환", response = HouseInfo.class)
	public ResponseEntity<List<HouseDeal>> getHouseDeal(@PathVariable String aptCode, @RequestParam String dealYear) throws SQLException {
		System.out.println(aptCode);
		System.out.println(dealYear);
		
		List<HouseDeal> list = HDService.select(aptCode, dealYear);

		return new ResponseEntity<List<HouseDeal>>(list, HttpStatus.OK);
	}
	

	

}