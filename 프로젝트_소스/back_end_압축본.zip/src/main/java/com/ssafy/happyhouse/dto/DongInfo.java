package com.ssafy.happyhouse.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DongInfo {
	private String dong;
	private String dongCode;
	private String gugunCode;
}
