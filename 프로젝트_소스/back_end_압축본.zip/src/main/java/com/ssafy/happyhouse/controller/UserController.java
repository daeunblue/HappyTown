package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.User;
import com.ssafy.happyhouse.model.service.UserService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
@RestController
@RequestMapping("/user")
@CrossOrigin("*")
@Slf4j
public class UserController {
	@Autowired
	UserService service;
	
	@PostMapping("/register")
	@ApiOperation(value = "회원가입")
	public ResponseEntity<Map> userJoin(@RequestBody User user) {
		log.debug("회원가입 : {}",user);
		Map<String, Object> map = new HashMap<>();
		try {
			service.registerUser(user);
			map.put("success", true);			
		} catch(Exception e) {
			map.put("success", false);
			map.put("msg", "가입 실패\n"+e.getMessage());
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	

	@PostMapping("/login")
	@ApiOperation(value = "로그인")
	public ResponseEntity<Map> userLogin(@RequestBody Map<String, Object> loginMap)  {
		String id = (String)loginMap.get("id");
		String password = (String)loginMap.get("password");
		Map<String, Object> map = new HashMap<>();
		
		try{
			User loginUser = service.login(id, password);
			map.put("success", true);
			map.put("data", loginUser);
			map.put("jwt-auth-token", loginUser.getAuthToken()); // 토큰정보(jwt-auth-token) 클라이언트에게 전달
			log.info("로그인 성공 : {}", loginUser);
		}catch(Exception e) {
			map.put("success", false);
			map.put("msg", e.getMessage());
		}
		
		return new ResponseEntity<>(map, HttpStatus.ACCEPTED);	
	}
}
