package com.ssafy.happyhouse.model.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class KakaoLogin {
	
    public String getAccessToken(String authorize_code) {
        String access_Token = "";
        String refresh_Token = "";
        String reqURL = "https://kauth.kakao.com/oauth/token";

        try {
            URL url = new URL(reqURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            
            System.out.println("코드 = "+authorize_code);

            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
            StringBuilder sb = new StringBuilder();
            sb.append("grant_type=authorization_code");
            sb.append("&client_id=af19bb5087982aa80afec24c84c155ef");
            sb.append("&redirect_uri=http://ssafy.ddns.net/");
            sb.append("&code=" + authorize_code);
            bw.write(sb.toString());
            bw.flush();


            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line = "";
            String result = "";

            while ((line = br.readLine()) != null) {
                result += line;
            }

            ObjectMapper objectMapper = new ObjectMapper();
            
            @SuppressWarnings("unchecked")
			Map<String, String> map = objectMapper.readValue(result, Map.class);
            System.out.println("반환 JSON map = "+map);
            
            access_Token = map.get("access_token");
            //access_Token = map.get("refresh_token");

            br.close();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println("access_token = "+access_Token);
        return access_Token;
    }

    public HashMap<String, Object> getUserInfo(String access_Token) {

        HashMap<String, Object> userInfo = new HashMap<>();
        String reqURL = "https://kapi.kakao.com/v2/user/me";

        try {
            URL url = new URL(reqURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            conn.setRequestProperty("Authorization", "Bearer " + access_Token);

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            String line = "";
            String result = "";

            while ((line = br.readLine()) != null) {
                result += line;
            }

            ObjectMapper objectMapper = new ObjectMapper();
            
			@SuppressWarnings("unchecked")
			Map<String, Object> map = objectMapper.readValue(result, Map.class);
            
            System.out.println(map);
            
            userInfo.put("id", map.get("id"));
            userInfo.put("name", ((Map<String, Object>)map.get("properties")).get("nickname"));
//
//            JsonObject kakao_account = element.getAsJsonObject().get("kakao_account").getAsJsonObject();
//            
//            String id = element.getAsJsonObject().get("id").getAsString();
//            String email = null;
//            if (kakao_account.getAsJsonObject().get("email") != null) {
//                email = kakao_account.getAsJsonObject().get("email").getAsString();
//                userInfo.put("id", id);
//                userInfo.put("email", email);
//            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        

        return userInfo;
    }

}
