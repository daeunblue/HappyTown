package com.ssafy.happyhouse;

import java.util.Arrays;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ssafy.happyhouse.interceptor.JwtInterceptor;

@SpringBootApplication
@MapperScan("com.ssafy.happyhouse.model.repo") //Repository 처리 
public class HappyhouseVueBackendApplication implements WebMvcConfigurer{

	public static void main(String[] args) {
		SpringApplication.run(HappyhouseVueBackendApplication.class, args);
	}
	
	@Autowired
	private JwtInterceptor jwtInterceptor;
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(jwtInterceptor).addPathPatterns("/api/**").excludePathPatterns(Arrays.asList("/user/**"));
	}

}
