package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.dto.AptSale;
import com.ssafy.happyhouse.dto.Comment;
import com.ssafy.happyhouse.dto.Post;
import com.ssafy.happyhouse.model.repo.CommentRepo;
import com.ssafy.happyhouse.model.repo.NotificationRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CommentServiceImpl implements CommentService {

	@Autowired
	CommentRepo repo;
	
	@Autowired
	NotificationRepo notiRepo;
	
	@Autowired
	PostService pService;
	
	@Autowired
	AptSaleService aService;
	
	@Override
	public int registComment(Comment comment) throws SQLException {
		// aptSale
		// 사실 name
		
		String regName = "";
		log.debug("댓글 정보 "+comment);
		// 매물에가서 찾고
		if(comment.getPostNo() > 10000) {
			AptSale aptSale = aService.selectAptSale(comment.getPostNo()-10000);
			regName = aptSale.getRegId();
		}
		// QnA가서 찾고
		else {
			Post post = pService.selectPost(comment.getPostNo());
			regName = post.getRegId();
		}

		if(regName.startsWith("[kakao]")) {
			regName = regName.substring(7); 
		}
		
		
		@SuppressWarnings("rawtypes")
		Map map = new HashMap();
		map.put("name", regName);
		map.put("msg", comment.getContent());
		
		
		notiRepo.msg(map);
		
		return repo.insert(comment);
	}

	@Override
	public int updateComment(Comment comment) throws SQLException {
		return repo.update(comment);
	}

	@Override
	public int deleteComment(int no) throws SQLException {
		return repo.delete(no);
	}

	@Override
	public List<Comment> selectAll(int postNo) throws SQLException {
		return repo.selectAll(postNo);
	}

}
