package com.ssafy.happyhouse.model.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.dto.AptSale;
import com.ssafy.happyhouse.dto.User;
import com.ssafy.happyhouse.model.repo.NotificationRepo;
import com.ssafy.happyhouse.model.repo.UserRepo;
import com.ssafy.happyhouse.util.JwtUtil;

@Service(value = "userService")
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo repo;
	
	@Autowired
	NotificationRepo notiRepo;
	
	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	JwtUtil jwtUtil;

	@Override
	public int registerUser(User user) throws Exception {
		
		notiRepo.welcome(user.getId());
		user.setPassword(encoder.encode(user.getPassword()));
		return repo.insert(user);
	}
	
	@Override
	public User login(String id, String password) throws Exception {
		User user = repo.select(id);
		if(user != null && encoder.matches(password, user.getPassword())) {
			// 인증 성공 -> authToken 생성
			Map<String,String> map = new HashMap<>();
			String authToken = jwtUtil.createAuthToken(map);
			user.setAuthToken(authToken);
			
			
			
			
			return user; 
		}
		if(user == null) throw new Exception("존재하지 않는 아이디입니다");
		throw new Exception("로그인 실패");
	}
	@Override
	public int updateUser(User user) throws Exception {
		return repo.update(user);
	}
	
	@Override
	public int updatePassword(User user) throws Exception {
		user.setPassword(encoder.encode(user.getPassword()));
		return repo.updatePassword(user);
	}
	
	@Override
	public int deleteUser(String id) throws Exception {
		return repo.delete(id);
	}
	
	@Override
	public User selectUser(String id) throws Exception {
		return repo.select(id);
	}
	
	@Override
	public boolean matchUser(String id, String name) throws Exception {
		User user = repo.select(id);
		if(user != null && user.getName().equals(name)) {
			return true;
		}
		if(user == null) throw new Exception("존재하지 않는 아이디입니다");
		throw new Exception("아이디와 이름이 맞지 않습니다.");
	}

}
