package com.ssafy.happyhouse.model.service;

import com.ssafy.happyhouse.dto.User;

public interface UserService {
	int registerUser(User user) throws Exception;

	User login(String id, String password) throws Exception;

	int updateUser(User user) throws Exception;
	
	int updatePassword(User user) throws Exception;

	int deleteUser(String id) throws Exception;
	
	User selectUser(String id) throws Exception;
	
	boolean matchUser(String id, String name) throws Exception;
	
	
}
