package com.ssafy.happyhouse.model.repo;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.dto.Comment;
import com.ssafy.happyhouse.dto.Post;

public interface CommentRepo {
	
	int insert(Comment comment) throws SQLException;
	
	int update(Comment comment) throws SQLException;
	
	int delete(int no) throws SQLException;
	
	List<Comment> selectAll(int postNo) throws SQLException;
	
	
}
