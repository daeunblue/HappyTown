package com.ssafy.happyhouse.model.repo;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.dto.HouseDeal;

public interface HouseDealRepo {
	List<HouseDeal> select(Map<String, String> map);
}
