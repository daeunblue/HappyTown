package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.LocationInfo;

public interface HouseInfoService {

	List<HouseInfo> selectByLocation(LocationInfo locationInfo);
	List<DongInfo> selectByUserId(String userId);
}
