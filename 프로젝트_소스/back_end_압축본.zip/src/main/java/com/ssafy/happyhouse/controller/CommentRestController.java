package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.Comment;
import com.ssafy.happyhouse.model.service.CommentService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/comment")
@CrossOrigin("*")
public class CommentRestController {
	
	@Autowired
	CommentService cService;
	
	@GetMapping("/{postNo}")
	@ApiOperation(value="{postNo}에 대한 댓글 목록 반환", response = Comment.class)
	public ResponseEntity<List<Comment>> selectAll(@PathVariable int postNo) throws SQLException{
		List<Comment> result = cService.selectAll(postNo);
		return new ResponseEntity<List<Comment>>(result, HttpStatus.OK);
	}
	
	@PostMapping("/{postNo}")
	@ApiOperation(value="전달받은 정보  추가", response = Integer.class)
	public ResponseEntity<Integer> insert(@RequestBody Map<String, String> commentMap, @PathVariable int postNo) throws SQLException{
		Comment comment = Comment.builder().content(commentMap.get("content")).id(commentMap.get("id")).postNo(postNo).build();
		int result = cService.registComment(comment);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	
	@PutMapping
	@ApiOperation(value="전달받은 정보 수정", response = Integer.class)
	public ResponseEntity<Integer> update(@RequestBody Comment comment) throws SQLException{
		int result = cService.updateComment(comment);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	
	@DeleteMapping("{no}")
	@ApiOperation(value="{no}에 해당하는 댓글 정보 삭제", response = Integer.class)
	public ResponseEntity<Integer> delete(@PathVariable int no) throws SQLException{
		int result = cService.deleteComment(no);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	

}
