package com.ssafy.happyhouse.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan(basePackages = "com.ssafy.happyhouse.aspect")
@EnableAspectJAutoProxy
public class AopConfig {

}
