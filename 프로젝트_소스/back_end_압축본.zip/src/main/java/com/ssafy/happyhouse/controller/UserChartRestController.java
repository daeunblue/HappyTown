package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.AvgDealAmount;
import com.ssafy.happyhouse.dto.DongInfo;
import com.ssafy.happyhouse.dto.GugunInfo;
import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.StoreCnt;
import com.ssafy.happyhouse.model.service.AvgDealAmountService;
import com.ssafy.happyhouse.model.service.GugunInfoService;
import com.ssafy.happyhouse.model.service.HouseInfoService;
import com.ssafy.happyhouse.model.service.StoreCntService;
import com.ssafy.happyhouse.model.service.UserInterestHouseService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/uChart")
@CrossOrigin("*")
@Slf4j
public class UserChartRestController {

	@Autowired
	GugunInfoService gService;

	@Autowired
	AvgDealAmountService aService;

	@Autowired
	UserInterestHouseService iService;

	@Autowired
	HouseInfoService hService;

	@Autowired
	StoreCntService sService;

	@GetMapping("/{userId}")
	@ApiOperation(value = "{userId}의 관심목록에 대한 동네 정보 반환", response = GugunInfo.class)
	public ResponseEntity<List<GugunInfo>> searchInfoById(@PathVariable String userId) throws SQLException {
		List<GugunInfo> result = new ArrayList<GugunInfo>();
		// 1. {userId}의 관심 아파트 코드들을 가져온다.
		// 2. 아파트 코드들을 기반으로, 중복 제거해서 동 관련 정보를 가져온다.
		List<DongInfo> dongList = hService.selectByUserId(userId);
		log.debug("동 결과: {}", dongList);
		// 3. 동 관련 정보를 통해 범죄율 관련 정보를 클라이언트에게 제공한다.
		for (DongInfo info : dongList) {
			GugunInfo gugunInfo = gService.searchByName(info.getGugunCode()).get(0);
			if(gugunInfo != null) {				
				gugunInfo.setDongName(info.getDong());
				result.add(gugunInfo);
				log.debug("정보 : {}", gugunInfo.toString());
			}
		}

		log.debug("최종 결과: {}", result);
		return new ResponseEntity<List<GugunInfo>>(result, HttpStatus.OK);
//		if (result.size() != 0) {
//			return new ResponseEntity<List<GugunInfo>>(result, HttpStatus.OK);
//		} else {
//			return new ResponseEntity<List<GugunInfo>>(result, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
	}

	@GetMapping("/deal/{userId}")
	@ApiOperation(value = "{userId}의 관심목록에 대한 거래 정보 반환", response = AvgDealAmount.class)
	public ResponseEntity<List<AvgDealAmount>> searchDealById(@PathVariable String userId) {
		List<AvgDealAmount> result = new ArrayList<AvgDealAmount>();

		List<DongInfo> dongList = hService.selectByUserId(userId);
		log.debug("동 리스트 : {}", dongList);
		for (DongInfo info : dongList) {
			Double deal = aService.getDongAvg(info.getDongCode());
			if(deal != null) {				
				log.debug(deal.toString());
				AvgDealAmount amount = new AvgDealAmount().builder().dongCode(info.getDongCode()).avgDealAmountPerArea(deal)
						.dongName(info.getDong()).build();
				result.add(amount);
			}
		}
		log.debug("최종 결과 : {}", result);
		return new ResponseEntity<List<AvgDealAmount>>(result, HttpStatus.OK);
//		if (result.size() != 0) {
//			return new ResponseEntity<List<AvgDealAmount>>(result, HttpStatus.OK);
//		} else {
//			return new ResponseEntity<List<AvgDealAmount>>(result, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
	}

	@GetMapping("/store/{kind}/{userId}")
	@ApiOperation(value = "{userId}의 관심 목록에 대한 교육 지수 정보 반환", response = HouseInfo.class)
	public ResponseEntity<List<StoreCnt>> searchStoreByKind(@PathVariable String kind, @PathVariable String userId) {
		List<StoreCnt> result = new ArrayList<StoreCnt>();
		List<DongInfo> dongList = hService.selectByUserId(userId);
		
		for (DongInfo info : dongList) {
			StoreCnt cnt = sService.selectById(kind, info.getDongCode());
			if(cnt!= null) {				
				log.debug(cnt.toString());
				cnt.setDongName(info.getDong());
				result.add(cnt);
			}
		}
		return new ResponseEntity<List<StoreCnt>>(result, HttpStatus.OK);
//		if (result.size() != 0) {
//			return new ResponseEntity<List<StoreCnt>>(result, HttpStatus.OK);
//		} else {
//			return new ResponseEntity<List<StoreCnt>>(result, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
	}
	
	
	
}
