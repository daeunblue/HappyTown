package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.AvgDealAmount;
import com.ssafy.happyhouse.dto.GugunInfo;
import com.ssafy.happyhouse.dto.StoreCnt;
import com.ssafy.happyhouse.model.service.AvgDealAmountService;
import com.ssafy.happyhouse.model.service.GugunInfoService;
import com.ssafy.happyhouse.model.service.StoreCntService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/chart")
@CrossOrigin("*")
@Slf4j
public class ChartRestController {

	@Autowired
	GugunInfoService gService;
	
	@Autowired
	AvgDealAmountService aService;
	
	@Autowired
	StoreCntService sService;
	
	@GetMapping("/gugunInfo/{gugunCode}")
	@ApiOperation(value = "{gugunCode}에 대한 구 추가 정보(인구수, 범죄발생수, 범죄율, 공원개수, 공원면적) 반환", response = GugunInfo.class)
	public ResponseEntity<List<GugunInfo>> selectByGugunCode(@PathVariable String gugunCode) throws SQLException {
		List<GugunInfo> result = gService.searchByName(gugunCode);
		return new ResponseEntity<List<GugunInfo>>(result, HttpStatus.OK);
	}
	
	@GetMapping("/deal/{gugunCode}")
	@ApiOperation(value="{gugunCode}에 해당하는 모든 동의 평균 가격 정보 반환", response = AvgDealAmount.class)
	public ResponseEntity<List<AvgDealAmount>> selectDealByGugunCode(@PathVariable String gugunCode) throws SQLException{
		List<AvgDealAmount> list = aService.getGuInfo(gugunCode);
		return new ResponseEntity<List<AvgDealAmount>>(list, HttpStatus.OK);
	}
	
	@GetMapping("/store/{kind}/{gugunCode}")
	@ApiOperation(value="{gugunCode}에 해당하는 모든 동의 평균 가격 정보 반환", response = AvgDealAmount.class)
	public ResponseEntity<List<StoreCnt>> selectStore(@PathVariable String kind, @PathVariable String gugunCode) throws SQLException{
		List<StoreCnt> list = sService.select(kind, gugunCode);
		return new ResponseEntity<List<StoreCnt>>(list, HttpStatus.OK);
	}
	
	

	
}
