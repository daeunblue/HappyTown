package com.ssafy.happyhouse.model.service;

import java.io.BufferedInputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.happyhouse.dto.AptSale;
import com.ssafy.happyhouse.model.repo.AptSaleRepo;
import com.ssafy.happyhouse.model.repo.NotificationRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AptSaleServiceImpl implements AptSaleService {

	@Autowired
	AptSaleRepo repo;
	
	@Autowired
	NotificationRepo notiRepo;
	
	@Override
	public int registAptSale(AptSale aptSale, MultipartFile imgfile) throws SQLException {
		byte[] bytes;
		try {
			bytes = imgfile.getBytes();
			
			aptSale.setImg(bytes);
			
//			String base64Encode = byteToBase64(bytes);
//			base64Encode = "data:image/png;base64," + base64Encode;
//			System.out.println(base64Encode);
			log.debug("here : {}", aptSale);
			int result = repo.insertAptSale(aptSale);
			// 알림에 등록
			notiRepo.insert(aptSale);
			return result;
			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public AptSale selectAptSale(int no) throws SQLException {
		Map<String, Object> map = repo.selectAptSale(no);
		
		if(map == null) {
			return null;
		}

		byte[] arr = (byte[])map.get("img");
		String base64Encode = "data:image/png;base64," + byteToBase64(arr);
		
		AptSale aptSale = AptSale.builder()
				.no((int) map.get("no"))
				.title((String) map.get("title"))
				.content((String) map.get("content"))
				.dongName((String) map.get("dongName"))
				.aptName((String) map.get("aptName"))
				.regId((String) map.get("regId"))
				.imgSrcUrl(base64Encode)
				.build();

		return aptSale;
	}

	@Override
	public List<AptSale> selectAptSaleAll() throws SQLException {
		// map 으로 DB 결과 넘겨받음
		List<Map<String, Object>> list = repo.selectAptSaleAll();
		// 객체로 변환하여 담을 리스트
		List<AptSale> result = new ArrayList<>();
		for(Map<String, Object> map : list) {
			// Blob > byte 변환
			byte[] arr = (byte[])map.get("img");
			String base64Encode = "data:image/png;base64," + byteToBase64(arr);
			
			AptSale aptSale = AptSale.builder()
					.no((int) map.get("no"))
					.title((String) map.get("title"))
					.content((String) map.get("content"))
					.dongName((String) map.get("dongName"))
					.aptName((String) map.get("aptName"))
					.regId((String) map.get("regId"))
					.imgSrcUrl(base64Encode)
					.build();
					
			result.add(aptSale);
		}
		
		return result;
	}

	@Override
	public int updateAptSale(AptSale aptSale) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteAptSale(int no) throws SQLException {
		return repo.delete(no);
	}
	
    // [blob 데이터를 바이트로 변환해주는 메소드]
    private static byte[] blobToBytes(Blob blob) {
        BufferedInputStream is = null;
        byte[] bytes = null;
        try {
            is = new BufferedInputStream(blob.getBinaryStream());
            bytes = new byte[(int) blob.length()];
            int len = bytes.length;
            int offset = 0;
            int read = 0;

            while (offset < len
                    && (read = is.read(bytes, offset, len - offset)) >= 0) {
                offset += read;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bytes;
    }

    // [byte를 base64로 인코딩 해주는 메소드]
    private static String byteToBase64(byte[] arr) {
        String result = "";
        try {
            result = Base64Utils.encodeToString(arr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


}
