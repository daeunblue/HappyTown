package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.User;
import com.ssafy.happyhouse.model.service.KakaoLogin;
import com.ssafy.happyhouse.model.service.UserService;
import com.ssafy.happyhouse.util.JwtUtil;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@AllArgsConstructor
@RequestMapping("/oauth")
@CrossOrigin("*")
@Slf4j
public class OAuthController {
	
	@Autowired
	KakaoLogin kService;
	
	@Autowired
	UserService uService;
	
	@Autowired
	JwtUtil jwtUtil;

	@GetMapping("/kakao")
    @ResponseBody
    public ResponseEntity<Map> kakaoCallback(@RequestParam("code") String code) {
        System.out.println("요청왔다"+code);
        String access_token = kService.getAccessToken(code);;
        
        
        if(access_token != null) {
        	
        	Map<String, Object> map = kService.getUserInfo(access_token);
        	String authToken = jwtUtil.createAuthToken((Map)map);
        	
        	System.out.println(map);
        	System.out.println(map.get("id"));
        	
        	try {
        		if(uService.selectUser(String.valueOf((Long)map.get("id"))) != null) {
        			// 있으면 그만
        		}
        		else {
        			// 없으면 넣어줌
        			User user = User.builder()
        					.id(String.valueOf((Long)map.get("id")))
        					.address("kakao")
        					.password("kakao")
        					.name((String)map.get("name"))
        					.build();
        			uService.registerUser(user);
        		}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        	
        	map.put("token", authToken);
        	return new ResponseEntity<>(map, HttpStatus.OK);
        }

		

		
		return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
    }
	
}
