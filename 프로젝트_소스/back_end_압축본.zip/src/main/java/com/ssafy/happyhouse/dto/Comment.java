package com.ssafy.happyhouse.dto;

import java.sql.Timestamp;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Comment {
	private int no;
	
	private String content;
	
	private Timestamp time;
	
	private int postNo;
	
	private String id;
}
