package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.dto.Comment;

public interface CommentService {
	int registComment(Comment comment) throws SQLException;
	int updateComment(Comment comment) throws SQLException;
	int deleteComment(int no) throws SQLException;
	List<Comment> selectAll(int postNo) throws SQLException;
}
