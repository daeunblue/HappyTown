package com.ssafy.happyhouse.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class UserExceptionHandler {
	// UserRestController에서 발생하는 Exception 처리
	
	// ExpiredJwtException 처리 : 유효지간이 지난 토큰 사용 (형식은 맞음)
	@ExceptionHandler(ExpiredJwtException.class)
	public ResponseEntity<String> makeCookie(ExpiredJwtException e){
		log.error("expired jwt exception 발생 ! 유효기간이 지난 토큰을 사용중 입니다.",e);
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.UNAUTHORIZED);
	}
	
	// 잘못된 토큰을 이용하려고 하면 MalformedjwtException 발생

}
