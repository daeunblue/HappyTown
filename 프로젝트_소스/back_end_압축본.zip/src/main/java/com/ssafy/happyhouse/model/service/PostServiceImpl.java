package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.happyhouse.dto.Post;
import com.ssafy.happyhouse.model.repo.PostRepo;

@Service
@Transactional
public class PostServiceImpl implements PostService {

	@Autowired
	PostRepo repo;
	
	@Override
	public int registPost(Post post) throws SQLException {
		return repo.insert(post);
	}
	
	@Override
	public Post selectPost(int no) throws SQLException{
		repo.incrementViewCount(no);
		return repo.select(no);
	}
	
	@Override
	public List<Post> selectPostAll() throws SQLException {
		return repo.selectAll();
	}
	
	@Override
	public int updatePost(Post post) throws SQLException {
		return repo.update(post);
	}

	@Override
	public int deletePost(int no) throws SQLException {
		return repo.delete(no);
	}

	// 삭제하려는 유저와 로그인한 유저가 동일한지 확인하는 과정
	@Override
	public boolean matchUser(String regId, String id) {
		return false;
	}

	


}
