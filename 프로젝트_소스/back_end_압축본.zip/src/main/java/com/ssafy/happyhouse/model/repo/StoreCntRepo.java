package com.ssafy.happyhouse.model.repo;

import java.util.List;
import java.util.Map;

import com.ssafy.happyhouse.dto.StoreCnt;

public interface StoreCntRepo {

	List<StoreCnt> select(Map<String, String> condition);


	StoreCnt selectById(String kind, String dongCode);
}
