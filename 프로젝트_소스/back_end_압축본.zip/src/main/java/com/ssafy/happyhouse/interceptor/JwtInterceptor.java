package com.ssafy.happyhouse.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.ssafy.happyhouse.util.JwtUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JwtInterceptor implements HandlerInterceptor {
	@Autowired
	private JwtUtil jwtUtil;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		/* preflight 를 위한 OPTIONS 요청이 들어오면 Interceptor 과정 없이 PASS시켜주기 
		 * -> preflight란?  해당 서버로 OPTIONS 를 미리 보내보고 해당 응답을 확인한 후, 우리가 보낸 Http Method 가 지원하면 실제 요청
		 * */
		if(request.getMethod().equals("OPTIONS")) {
			return true;
		}
		// request - header에 있는 "jwt-auth-token" check
		String authToken = request.getHeader("jwt-auth-token");
		log.debug("요청 경로 : {}, 토큰 : {}", request.getServletPath(), authToken);
		
		if(authToken != null) {
			// 토큰 유효성 체크 
			jwtUtil.checkAndGetClaims(authToken);
			return true;
		}else {
			throw new RuntimeException("인증 토큰 없음");
		}
	}
}
