package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.Comment;
import com.ssafy.happyhouse.dto.Notification;
import com.ssafy.happyhouse.model.repo.NotificationRepo;
import com.ssafy.happyhouse.model.service.CommentService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/notification")
@CrossOrigin("*")
public class NotificationRestController {
	
	@Autowired
	NotificationRepo repo;
	
	@GetMapping("/{id}")
	@ApiOperation(value="{userId}에 대한 알림 목록 반환", response = Comment.class)
	public ResponseEntity<List<Notification>> select(@PathVariable String id) throws SQLException{
		List<Notification> result = repo.select(id);
		return new ResponseEntity<List<Notification>>(result, HttpStatus.OK);
	}
	
	@DeleteMapping("/{no}")
	@ApiOperation(value="알림 삭제", response = Integer.class)
	public ResponseEntity<Integer> delete( @PathVariable int no) throws SQLException{
		int result = repo.delete(no);
		return new ResponseEntity<Integer>(result, HttpStatus.OK);
	}
	

	

}
