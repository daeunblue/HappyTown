package com.ssafy.happyhouse.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.HouseInfo;
import com.ssafy.happyhouse.dto.UserInterest;
import com.ssafy.happyhouse.model.service.UserInterestHouseService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/interest")
@CrossOrigin("*")
@Slf4j
public class UserInterestRestController {
	
	@Autowired
	UserInterestHouseService iService;
	
	@GetMapping("/{userId}")
	@ApiOperation(value = "{userId}의 관심 아파트 목록 반환", response = List.class)
	public ResponseEntity<List<HouseInfo>> selectById(@PathVariable String userId) throws SQLException{
		List<HouseInfo> result = iService.selectUserHouse(userId);
		return new ResponseEntity<List<HouseInfo>>(result, HttpStatus.OK);
	}
	
	// 로그인 유저가 맞는지 유효성 검사 해야 하는데 백에서 처리해야하는지? 아니면 클라이언트에서 처리할지 ?	
	@DeleteMapping("/{houseInfoAptCode}/{userId}")
	@ApiOperation(value = "{userid}의 {aptCode}에 해당하는 관심 목록 삭제" , response = Integer.class)
	public ResponseEntity<Integer> deleteInterest(@PathVariable String houseInfoAptCode, @PathVariable String userId)throws SQLException{
		System.out.println(houseInfoAptCode);
		
		UserInterest interest = new UserInterest().builder().houseInfoAptCode(houseInfoAptCode).userId(userId).build();
		int result = iService.deleteInterest(interest);

		System.out.println("interest : "+interest.toString());
		if(result == 1) {
			return new ResponseEntity<Integer>(result, HttpStatus.OK);
		}else {
			return new ResponseEntity<Integer>(result, HttpStatus.METHOD_NOT_ALLOWED);
		}
	}

	@PostMapping
	@ApiOperation(value = "전달받은 관심 APT 정보 저장", response = Integer.class)
	public ResponseEntity<Integer> insertInterest(@RequestBody UserInterest interest)throws SQLException{
		// 이미 해당 user가, 아파트를 찜한적이 있는지 확인하자.
		List<HouseInfo> existResult = iService.selectUserHouse(interest.getUserId());
		for(HouseInfo hinfo : existResult) {
//			System.out.println(hinfo.getAptCode() +", "+ interest.getHouseInfoAptCode()+","+hinfo.getAptCode().equals(interest.getHouseInfoAptCode()));
			if(hinfo.getAptCode().equals(interest.getHouseInfoAptCode())) {
				// 중복된 결과 -> 추가 불가능
				//return new ResponseEntity<Integer>(-1, HttpStatus.BAD_REQUEST);	// 400에러 전달 -> 잘못된 요청 (중복 데이터 전달) 이므로 클라이언트에게 오류 전달
				return new ResponseEntity<Integer>(-1, HttpStatus.OK);	// 200에러 전달하고 -1로 알려줌 (400이면 error로 처리하니까)
			}
		}
		
		int result = iService.insertInterest(interest);
		if(result == 1) {
			return new ResponseEntity<Integer>(result, HttpStatus.OK);
		}else {
			return new ResponseEntity<Integer>(result, HttpStatus.INTERNAL_SERVER_ERROR); // 500에러 반환 -> sql 오류는 서버 오류
		}
	}
	
	
}
