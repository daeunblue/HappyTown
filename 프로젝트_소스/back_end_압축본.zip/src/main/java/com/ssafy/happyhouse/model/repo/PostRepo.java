package com.ssafy.happyhouse.model.repo;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.dto.Post;

public interface PostRepo {
	int insert(Post post) throws SQLException;
	
	int update(Post post) throws SQLException;
	
	int incrementViewCount(int no) throws SQLException;
	
	int delete(int no) throws SQLException;
	
	Post select(int no) throws SQLException;
	
	List<Post> selectAll() throws SQLException;
	/* 작성자 아이디로 게시글 검색*/
	List<Post> searchById(String regId) throws SQLException;
	
	

}
