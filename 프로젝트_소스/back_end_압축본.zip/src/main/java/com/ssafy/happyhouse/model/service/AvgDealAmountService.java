package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.dto.AvgDealAmount;

public interface AvgDealAmountService {
	Double getGuAvg(String dongCode);
	
	List<AvgDealAmount> getGuInfo(String dongCode);
	
	Double getDongAvg(String dongCode);
}
