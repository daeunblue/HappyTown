package com.ssafy.happyhouse.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.HouseDeal;
import com.ssafy.happyhouse.model.repo.HouseDealRepo;

@Service
public class HouseDealServiceImpl implements HouseDealService {
	
	@Autowired
	HouseDealRepo repo;

	@Override
	public List<HouseDeal> select(String aptCode, String dealYear) {
		Map<String, String> condition = new HashMap<>();
		condition.put("aptCode", aptCode);
		condition.put("dealYear", dealYear);
		return repo.select(condition);
	}

}
